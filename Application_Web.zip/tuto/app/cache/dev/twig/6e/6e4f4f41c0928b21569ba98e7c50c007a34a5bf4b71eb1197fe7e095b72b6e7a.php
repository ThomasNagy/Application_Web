<?php

/* @Twig/Exception/exception.json.twig */
class __TwigTemplate_f055a61ff89e0be4410f79b97e8f4a5e0c3209525b9c8c86154235e4d2180874 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_78d5970d9e353669b7aadb4e4913475a142013cd8af5bf58cb263f88e8a41d1c = $this->env->getExtension("native_profiler");
        $__internal_78d5970d9e353669b7aadb4e4913475a142013cd8af5bf58cb263f88e8a41d1c->enter($__internal_78d5970d9e353669b7aadb4e4913475a142013cd8af5bf58cb263f88e8a41d1c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "message" => (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "exception" => $this->getAttribute((isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")), "toarray", array()))));
        echo "
";
        
        $__internal_78d5970d9e353669b7aadb4e4913475a142013cd8af5bf58cb263f88e8a41d1c->leave($__internal_78d5970d9e353669b7aadb4e4913475a142013cd8af5bf58cb263f88e8a41d1c_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {{ { 'error': { 'code': status_code, 'message': status_text, 'exception': exception.toarray } }|json_encode|raw }}*/
/* */
