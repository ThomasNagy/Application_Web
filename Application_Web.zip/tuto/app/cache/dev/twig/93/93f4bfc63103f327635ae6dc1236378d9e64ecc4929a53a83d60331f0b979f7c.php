<?php

/* @Framework/Form/form.html.php */
class __TwigTemplate_507f94ff3061aebcf851369b3eb4e9e6092b9516bf41a7fa7ab849d6cb82696b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e7a3e0de69a9743fd253b2925d8a2456b3e22aea546333ad8554ac8326079770 = $this->env->getExtension("native_profiler");
        $__internal_e7a3e0de69a9743fd253b2925d8a2456b3e22aea546333ad8554ac8326079770->enter($__internal_e7a3e0de69a9743fd253b2925d8a2456b3e22aea546333ad8554ac8326079770_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form.html.php"));

        // line 1
        echo "<?php echo \$view['form']->start(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
<?php echo \$view['form']->end(\$form) ?>
";
        
        $__internal_e7a3e0de69a9743fd253b2925d8a2456b3e22aea546333ad8554ac8326079770->leave($__internal_e7a3e0de69a9743fd253b2925d8a2456b3e22aea546333ad8554ac8326079770_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->start($form) ?>*/
/*     <?php echo $view['form']->widget($form) ?>*/
/* <?php echo $view['form']->end($form) ?>*/
/* */
