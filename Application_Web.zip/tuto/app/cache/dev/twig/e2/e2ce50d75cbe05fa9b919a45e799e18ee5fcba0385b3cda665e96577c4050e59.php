<?php

/* @Framework/Form/button_widget.html.php */
class __TwigTemplate_afeb3d5de256434b5522fbc92d0e521d3384c2feaea76b1f56b155cf8d9601ea extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_049420b8ff290a26f1dd341499a538ed95a99e41a91e0dc50b400b01edff7ca5 = $this->env->getExtension("native_profiler");
        $__internal_049420b8ff290a26f1dd341499a538ed95a99e41a91e0dc50b400b01edff7ca5->enter($__internal_049420b8ff290a26f1dd341499a538ed95a99e41a91e0dc50b400b01edff7ca5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_widget.html.php"));

        // line 1
        echo "<?php if (!\$label) { \$label = isset(\$label_format)
    ? strtr(\$label_format, array('%name%' => \$name, '%id%' => \$id))
    : \$view['form']->humanize(\$name); } ?>
<button type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'button' ?>\" <?php echo \$view['form']->block(\$form, 'button_attributes') ?>><?php echo \$view->escape(false !== \$translation_domain ? \$view['translator']->trans(\$label, array(), \$translation_domain) : \$label) ?></button>
";
        
        $__internal_049420b8ff290a26f1dd341499a538ed95a99e41a91e0dc50b400b01edff7ca5->leave($__internal_049420b8ff290a26f1dd341499a538ed95a99e41a91e0dc50b400b01edff7ca5_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if (!$label) { $label = isset($label_format)*/
/*     ? strtr($label_format, array('%name%' => $name, '%id%' => $id))*/
/*     : $view['form']->humanize($name); } ?>*/
/* <button type="<?php echo isset($type) ? $view->escape($type) : 'button' ?>" <?php echo $view['form']->block($form, 'button_attributes') ?>><?php echo $view->escape(false !== $translation_domain ? $view['translator']->trans($label, array(), $translation_domain) : $label) ?></button>*/
/* */
