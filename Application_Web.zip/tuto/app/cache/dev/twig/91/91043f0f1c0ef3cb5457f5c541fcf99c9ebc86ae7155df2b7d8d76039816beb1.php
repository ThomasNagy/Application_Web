<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_ccbb4163b0ddcfe1015a9c61ff150f0aa2ea11dbfe08f66b04d6c78e4ffd7b9f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_46c227342d24a2716148abd56f803bca661195c89e3a3a1d67ea17af2d462051 = $this->env->getExtension("native_profiler");
        $__internal_46c227342d24a2716148abd56f803bca661195c89e3a3a1d67ea17af2d462051->enter($__internal_46c227342d24a2716148abd56f803bca661195c89e3a3a1d67ea17af2d462051_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_46c227342d24a2716148abd56f803bca661195c89e3a3a1d67ea17af2d462051->leave($__internal_46c227342d24a2716148abd56f803bca661195c89e3a3a1d67ea17af2d462051_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }
}
