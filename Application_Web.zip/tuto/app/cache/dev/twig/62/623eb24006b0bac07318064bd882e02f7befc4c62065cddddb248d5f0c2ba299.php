<?php

/* @Framework/Form/form_row.html.php */
class __TwigTemplate_3a860cd3479f1dbca4e1150304ff7196d5fabfd1a8dd39a5ed01329a3ed4dc23 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4312dc285f86ef8e749ad2618af5ff785b3de2cd8e263b107fcfa0357bbc984b = $this->env->getExtension("native_profiler");
        $__internal_4312dc285f86ef8e749ad2618af5ff785b3de2cd8e263b107fcfa0357bbc984b->enter($__internal_4312dc285f86ef8e749ad2618af5ff785b3de2cd8e263b107fcfa0357bbc984b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->label(\$form) ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_4312dc285f86ef8e749ad2618af5ff785b3de2cd8e263b107fcfa0357bbc984b->leave($__internal_4312dc285f86ef8e749ad2618af5ff785b3de2cd8e263b107fcfa0357bbc984b_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div>*/
/*     <?php echo $view['form']->label($form) ?>*/
/*     <?php echo $view['form']->errors($form) ?>*/
/*     <?php echo $view['form']->widget($form) ?>*/
/* </div>*/
/* */
