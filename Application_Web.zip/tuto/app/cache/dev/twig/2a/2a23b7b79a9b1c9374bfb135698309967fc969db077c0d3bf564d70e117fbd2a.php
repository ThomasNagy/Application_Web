<?php

/* TwigBundle:Exception:exception.atom.twig */
class __TwigTemplate_7f306e226600b760fa126c858d6e996c2c185507cfe496b1cb9fadc33ada8ad3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2a9ec4b263e1ba913cefb0e833a86394f26cb881279f08a47bf0058f0c001adf = $this->env->getExtension("native_profiler");
        $__internal_2a9ec4b263e1ba913cefb0e833a86394f26cb881279f08a47bf0058f0c001adf->enter($__internal_2a9ec4b263e1ba913cefb0e833a86394f26cb881279f08a47bf0058f0c001adf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/exception.xml.twig", "TwigBundle:Exception:exception.atom.twig", 1)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        
        $__internal_2a9ec4b263e1ba913cefb0e833a86394f26cb881279f08a47bf0058f0c001adf->leave($__internal_2a9ec4b263e1ba913cefb0e833a86394f26cb881279f08a47bf0058f0c001adf_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/exception.xml.twig' with { 'exception': exception } %}*/
/* */
