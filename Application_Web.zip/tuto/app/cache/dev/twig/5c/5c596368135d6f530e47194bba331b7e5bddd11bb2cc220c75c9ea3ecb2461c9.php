<?php

/* @WebProfiler/Profiler/ajax_layout.html.twig */
class __TwigTemplate_9efe8832d4ea106083e20dc7c67cdc20efa335b3c18a72d439b8eb302fabc2ef extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_868e21442ba4852dcc98f782d0d767c6244b1632e43c449166404f4a5c4d3a21 = $this->env->getExtension("native_profiler");
        $__internal_868e21442ba4852dcc98f782d0d767c6244b1632e43c449166404f4a5c4d3a21->enter($__internal_868e21442ba4852dcc98f782d0d767c6244b1632e43c449166404f4a5c4d3a21_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_868e21442ba4852dcc98f782d0d767c6244b1632e43c449166404f4a5c4d3a21->leave($__internal_868e21442ba4852dcc98f782d0d767c6244b1632e43c449166404f4a5c4d3a21_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_7f83b041ef0cd0644b73e5a0cf3e436afe473664cb6beb0117486c7481198b54 = $this->env->getExtension("native_profiler");
        $__internal_7f83b041ef0cd0644b73e5a0cf3e436afe473664cb6beb0117486c7481198b54->enter($__internal_7f83b041ef0cd0644b73e5a0cf3e436afe473664cb6beb0117486c7481198b54_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_7f83b041ef0cd0644b73e5a0cf3e436afe473664cb6beb0117486c7481198b54->leave($__internal_7f83b041ef0cd0644b73e5a0cf3e436afe473664cb6beb0117486c7481198b54_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }
}
/* {% block panel '' %}*/
/* */
