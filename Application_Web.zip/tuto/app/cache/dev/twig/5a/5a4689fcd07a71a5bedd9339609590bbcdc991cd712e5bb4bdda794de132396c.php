<?php

/* @Twig/Exception/exception.js.twig */
class __TwigTemplate_0105fb3679e8f401fea89525d262d7ca9fedb4897a236d584228776a0f2eec9e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_df218902ca6633d34b83ac3fba99e61a26210c984ced65beefb5ad3fface157a = $this->env->getExtension("native_profiler");
        $__internal_df218902ca6633d34b83ac3fba99e61a26210c984ced65beefb5ad3fface157a->enter($__internal_df218902ca6633d34b83ac3fba99e61a26210c984ced65beefb5ad3fface157a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        $this->loadTemplate("@Twig/Exception/exception.txt.twig", "@Twig/Exception/exception.js.twig", 2)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        // line 3
        echo "*/
";
        
        $__internal_df218902ca6633d34b83ac3fba99e61a26210c984ced65beefb5ad3fface157a->leave($__internal_df218902ca6633d34b83ac3fba99e61a26210c984ced65beefb5ad3fface157a_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  27 => 3,  25 => 2,  22 => 1,);
    }
}
/* /**/
/* {% include '@Twig/Exception/exception.txt.twig' with { 'exception': exception } %}*/
/* *//* */
/* */
