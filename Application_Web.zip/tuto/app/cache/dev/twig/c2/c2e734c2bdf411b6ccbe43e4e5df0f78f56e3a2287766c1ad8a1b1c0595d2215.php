<?php

/* @OCPlatform/Blog/translation.html.twig */
class __TwigTemplate_bd2a120ac24031f46f0041a11b3c5301eb0bf4af1a9db120f40cf566d5a2d10c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ca7269e6e152ae8a6cf5d4ca87984ee9ce7ed13377a0d7b93dcd48e6ff4dfe33 = $this->env->getExtension("native_profiler");
        $__internal_ca7269e6e152ae8a6cf5d4ca87984ee9ce7ed13377a0d7b93dcd48e6ff4dfe33->enter($__internal_ca7269e6e152ae8a6cf5d4ca87984ee9ce7ed13377a0d7b93dcd48e6ff4dfe33_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@OCPlatform/Blog/translation.html.twig"));

        // line 1
        echo "<html>
  <body>
    Hello ";
        // line 3
        echo twig_escape_filter($this->env, (isset($context["name"]) ? $context["name"] : $this->getContext($context, "name")), "html", null, true);
        echo "!
  </body>
</html>
";
        
        $__internal_ca7269e6e152ae8a6cf5d4ca87984ee9ce7ed13377a0d7b93dcd48e6ff4dfe33->leave($__internal_ca7269e6e152ae8a6cf5d4ca87984ee9ce7ed13377a0d7b93dcd48e6ff4dfe33_prof);

    }

    public function getTemplateName()
    {
        return "@OCPlatform/Blog/translation.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  26 => 3,  22 => 1,);
    }
}
/* <html>*/
/*   <body>*/
/*     Hello {{ name }}!*/
/*   </body>*/
/* </html>*/
/* */
