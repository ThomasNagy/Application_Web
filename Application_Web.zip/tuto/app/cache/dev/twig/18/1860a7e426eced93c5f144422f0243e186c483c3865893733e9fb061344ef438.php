<?php

/* @OCPlatform/Advert/form.html.twig */
class __TwigTemplate_338bd672e771b74ea7965d0e730ff080894d186f87901f7fb208f0ce3e1b71af extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9abf197ddb1c7a4529400e1117c7f27787fc9a568b56371776a892b31811cf01 = $this->env->getExtension("native_profiler");
        $__internal_9abf197ddb1c7a4529400e1117c7f27787fc9a568b56371776a892b31811cf01->enter($__internal_9abf197ddb1c7a4529400e1117c7f27787fc9a568b56371776a892b31811cf01_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@OCPlatform/Advert/form.html.twig"));

        // line 2
        echo "
<h3>Formulaire d'annonce</h3>

";
        // line 7
        echo "<div class=\"well\">
  Ici se trouvera le formulaire.
</div>";
        
        $__internal_9abf197ddb1c7a4529400e1117c7f27787fc9a568b56371776a892b31811cf01->leave($__internal_9abf197ddb1c7a4529400e1117c7f27787fc9a568b56371776a892b31811cf01_prof);

    }

    public function getTemplateName()
    {
        return "@OCPlatform/Advert/form.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  27 => 7,  22 => 2,);
    }
}
/* {# src/OC/PlatformBundle/Resources/views/Default/form.html.twig #}*/
/* */
/* <h3>Formulaire d'annonce</h3>*/
/* */
/* {# On laisse vide la vue pour l'instant, on la comblera plus tard*/
/*    lorsqu'on saura afficher un formulaire. #}*/
/* <div class="well">*/
/*   Ici se trouvera le formulaire.*/
/* </div>*/
