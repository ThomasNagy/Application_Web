<?php

/* @Framework/Form/range_widget.html.php */
class __TwigTemplate_06d6aa9d31bf07f2bbeea6500a552b782fc9d10f1c6318b703b05abf64a0b7fa extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e2f76b495240c6407fcab7c9e2db8b93d714c60076318cdb38c104eb0ba39ada = $this->env->getExtension("native_profiler");
        $__internal_e2f76b495240c6407fcab7c9e2db8b93d714c60076318cdb38c104eb0ba39ada->enter($__internal_e2f76b495240c6407fcab7c9e2db8b93d714c60076318cdb38c104eb0ba39ada_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/range_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'range'));
";
        
        $__internal_e2f76b495240c6407fcab7c9e2db8b93d714c60076318cdb38c104eb0ba39ada->leave($__internal_e2f76b495240c6407fcab7c9e2db8b93d714c60076318cdb38c104eb0ba39ada_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/range_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'range'));*/
/* */
