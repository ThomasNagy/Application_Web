<?php

/* base.html.twig */
class __TwigTemplate_394ab7cef4e6bd3a3bb141b3dbdd8d9d150cee3f68998731c0aac5eab24793b8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c985c74de324bf6089f8c82336417d7d8c5c74b1ec9a4c40c9e9caba4452c675 = $this->env->getExtension("native_profiler");
        $__internal_c985c74de324bf6089f8c82336417d7d8c5c74b1ec9a4c40c9e9caba4452c675->enter($__internal_c985c74de324bf6089f8c82336417d7d8c5c74b1ec9a4c40c9e9caba4452c675_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>
</html>
";
        
        $__internal_c985c74de324bf6089f8c82336417d7d8c5c74b1ec9a4c40c9e9caba4452c675->leave($__internal_c985c74de324bf6089f8c82336417d7d8c5c74b1ec9a4c40c9e9caba4452c675_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_af599985a5cf8f44828786058c9625059234bed9c25edfc1a8141f3af6c702aa = $this->env->getExtension("native_profiler");
        $__internal_af599985a5cf8f44828786058c9625059234bed9c25edfc1a8141f3af6c702aa->enter($__internal_af599985a5cf8f44828786058c9625059234bed9c25edfc1a8141f3af6c702aa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_af599985a5cf8f44828786058c9625059234bed9c25edfc1a8141f3af6c702aa->leave($__internal_af599985a5cf8f44828786058c9625059234bed9c25edfc1a8141f3af6c702aa_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_3df00d2b5b2545c8af6c5a883560fc0e488f5879cf050b7f7fa2734fd4f74b3d = $this->env->getExtension("native_profiler");
        $__internal_3df00d2b5b2545c8af6c5a883560fc0e488f5879cf050b7f7fa2734fd4f74b3d->enter($__internal_3df00d2b5b2545c8af6c5a883560fc0e488f5879cf050b7f7fa2734fd4f74b3d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_3df00d2b5b2545c8af6c5a883560fc0e488f5879cf050b7f7fa2734fd4f74b3d->leave($__internal_3df00d2b5b2545c8af6c5a883560fc0e488f5879cf050b7f7fa2734fd4f74b3d_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_00b3382871370964d24ffcdb4074496d13738682343e9519008ebfc36cd2bb10 = $this->env->getExtension("native_profiler");
        $__internal_00b3382871370964d24ffcdb4074496d13738682343e9519008ebfc36cd2bb10->enter($__internal_00b3382871370964d24ffcdb4074496d13738682343e9519008ebfc36cd2bb10_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_00b3382871370964d24ffcdb4074496d13738682343e9519008ebfc36cd2bb10->leave($__internal_00b3382871370964d24ffcdb4074496d13738682343e9519008ebfc36cd2bb10_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_9b7ab5cfe1b5c2eba05b1a950f54f71206193035142b7266204127a8f99d8773 = $this->env->getExtension("native_profiler");
        $__internal_9b7ab5cfe1b5c2eba05b1a950f54f71206193035142b7266204127a8f99d8773->enter($__internal_9b7ab5cfe1b5c2eba05b1a950f54f71206193035142b7266204127a8f99d8773_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_9b7ab5cfe1b5c2eba05b1a950f54f71206193035142b7266204127a8f99d8773->leave($__internal_9b7ab5cfe1b5c2eba05b1a950f54f71206193035142b7266204127a8f99d8773_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  93 => 11,  82 => 10,  71 => 6,  59 => 5,  50 => 12,  47 => 11,  45 => 10,  38 => 7,  36 => 6,  32 => 5,  26 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html>*/
/*     <head>*/
/*         <meta charset="UTF-8" />*/
/*         <title>{% block title %}Welcome!{% endblock %}</title>*/
/*         {% block stylesheets %}{% endblock %}*/
/*         <link rel="icon" type="image/x-icon" href="{{ asset('favicon.ico') }}" />*/
/*     </head>*/
/*     <body>*/
/*         {% block body %}{% endblock %}*/
/*         {% block javascripts %}{% endblock %}*/
/*     </body>*/
/* </html>*/
/* */
