<?php

/* @Twig/Exception/error.js.twig */
class __TwigTemplate_cf3f619ba22a9427e8651b811a4db4f48cb393ebb7cbfb768433376ed9bf1af1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9884fc8eaf85d652e558f3845833df355d0303d764f96618c1cdeef6bce80178 = $this->env->getExtension("native_profiler");
        $__internal_9884fc8eaf85d652e558f3845833df355d0303d764f96618c1cdeef6bce80178->enter($__internal_9884fc8eaf85d652e558f3845833df355d0303d764f96618c1cdeef6bce80178_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "js", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "js", null, true);
        echo "

*/
";
        
        $__internal_9884fc8eaf85d652e558f3845833df355d0303d764f96618c1cdeef6bce80178->leave($__internal_9884fc8eaf85d652e558f3845833df355d0303d764f96618c1cdeef6bce80178_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 2,  22 => 1,);
    }
}
/* /**/
/* {{ status_code }} {{ status_text }}*/
/* */
/* *//* */
/* */
