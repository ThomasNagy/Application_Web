<?php

/* TwigBundle:Exception:exception.css.twig */
class __TwigTemplate_d42ac24587c07c4fc3332a33aed12d793a2ff3a96b628d63f13c1deb90aee60e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_834898a98e31ebf4726819570995f8449d4f8d8184a80d11a0e0bc5fc8fa77a4 = $this->env->getExtension("native_profiler");
        $__internal_834898a98e31ebf4726819570995f8449d4f8d8184a80d11a0e0bc5fc8fa77a4->enter($__internal_834898a98e31ebf4726819570995f8449d4f8d8184a80d11a0e0bc5fc8fa77a4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        $this->loadTemplate("@Twig/Exception/exception.txt.twig", "TwigBundle:Exception:exception.css.twig", 2)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        // line 3
        echo "*/
";
        
        $__internal_834898a98e31ebf4726819570995f8449d4f8d8184a80d11a0e0bc5fc8fa77a4->leave($__internal_834898a98e31ebf4726819570995f8449d4f8d8184a80d11a0e0bc5fc8fa77a4_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  27 => 3,  25 => 2,  22 => 1,);
    }
}
/* /**/
/* {% include '@Twig/Exception/exception.txt.twig' with { 'exception': exception } %}*/
/* *//* */
/* */
