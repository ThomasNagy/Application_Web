<?php

/* ::base.html.twig */
class __TwigTemplate_0c1202c99f798aa8b9a5cb1cf275299f305d2dc31d836437640b02680540c68e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e404f10829f1c737454cae0b97c20f5e9d4d7b4c5a75cc0ffda2b36d801af530 = $this->env->getExtension("native_profiler");
        $__internal_e404f10829f1c737454cae0b97c20f5e9d4d7b4c5a75cc0ffda2b36d801af530->enter($__internal_e404f10829f1c737454cae0b97c20f5e9d4d7b4c5a75cc0ffda2b36d801af530_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>
</html>
";
        
        $__internal_e404f10829f1c737454cae0b97c20f5e9d4d7b4c5a75cc0ffda2b36d801af530->leave($__internal_e404f10829f1c737454cae0b97c20f5e9d4d7b4c5a75cc0ffda2b36d801af530_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_40bfc1082913e92013a0960db43db08ce95cefc96345019dba7ec5e7e8a90c8f = $this->env->getExtension("native_profiler");
        $__internal_40bfc1082913e92013a0960db43db08ce95cefc96345019dba7ec5e7e8a90c8f->enter($__internal_40bfc1082913e92013a0960db43db08ce95cefc96345019dba7ec5e7e8a90c8f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_40bfc1082913e92013a0960db43db08ce95cefc96345019dba7ec5e7e8a90c8f->leave($__internal_40bfc1082913e92013a0960db43db08ce95cefc96345019dba7ec5e7e8a90c8f_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_d0ed3fb91126bd578e99ad0173a1288a804754923b18a26814116cec270c4e3b = $this->env->getExtension("native_profiler");
        $__internal_d0ed3fb91126bd578e99ad0173a1288a804754923b18a26814116cec270c4e3b->enter($__internal_d0ed3fb91126bd578e99ad0173a1288a804754923b18a26814116cec270c4e3b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_d0ed3fb91126bd578e99ad0173a1288a804754923b18a26814116cec270c4e3b->leave($__internal_d0ed3fb91126bd578e99ad0173a1288a804754923b18a26814116cec270c4e3b_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_51648d2fab16b8956b6f5b4cf728770f3d33eb0db0a199d6318680bbe4901e54 = $this->env->getExtension("native_profiler");
        $__internal_51648d2fab16b8956b6f5b4cf728770f3d33eb0db0a199d6318680bbe4901e54->enter($__internal_51648d2fab16b8956b6f5b4cf728770f3d33eb0db0a199d6318680bbe4901e54_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_51648d2fab16b8956b6f5b4cf728770f3d33eb0db0a199d6318680bbe4901e54->leave($__internal_51648d2fab16b8956b6f5b4cf728770f3d33eb0db0a199d6318680bbe4901e54_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_72916cbc3ec83fefc61d84ff26b8a6b8fd9a1d30480aeaedddd4c558faf686e9 = $this->env->getExtension("native_profiler");
        $__internal_72916cbc3ec83fefc61d84ff26b8a6b8fd9a1d30480aeaedddd4c558faf686e9->enter($__internal_72916cbc3ec83fefc61d84ff26b8a6b8fd9a1d30480aeaedddd4c558faf686e9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_72916cbc3ec83fefc61d84ff26b8a6b8fd9a1d30480aeaedddd4c558faf686e9->leave($__internal_72916cbc3ec83fefc61d84ff26b8a6b8fd9a1d30480aeaedddd4c558faf686e9_prof);

    }

    public function getTemplateName()
    {
        return "::base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  93 => 11,  82 => 10,  71 => 6,  59 => 5,  50 => 12,  47 => 11,  45 => 10,  38 => 7,  36 => 6,  32 => 5,  26 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html>*/
/*     <head>*/
/*         <meta charset="UTF-8" />*/
/*         <title>{% block title %}Welcome!{% endblock %}</title>*/
/*         {% block stylesheets %}{% endblock %}*/
/*         <link rel="icon" type="image/x-icon" href="{{ asset('favicon.ico') }}" />*/
/*     </head>*/
/*     <body>*/
/*         {% block body %}{% endblock %}*/
/*         {% block javascripts %}{% endblock %}*/
/*     </body>*/
/* </html>*/
/* */
