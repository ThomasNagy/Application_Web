<?php

/* OCPlatformBundle:Default:add.html.twig */
class __TwigTemplate_d2e090f2829e5c94d4e888bc2dad0fdff59863cd8540a4abae85d7a6338ee71b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 3
        $this->parent = $this->loadTemplate("OCPlatformBundle::layout.html.twig", "OCPlatformBundle:Default:add.html.twig", 3);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "OCPlatformBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_542691cc6684e9c2997efd3bfa99d5d8093a93457d004fbf365641a68138ac26 = $this->env->getExtension("native_profiler");
        $__internal_542691cc6684e9c2997efd3bfa99d5d8093a93457d004fbf365641a68138ac26->enter($__internal_542691cc6684e9c2997efd3bfa99d5d8093a93457d004fbf365641a68138ac26_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle:Default:add.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_542691cc6684e9c2997efd3bfa99d5d8093a93457d004fbf365641a68138ac26->leave($__internal_542691cc6684e9c2997efd3bfa99d5d8093a93457d004fbf365641a68138ac26_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_837554ae43a4a41c0123fe2b8bf42286e9bb3a561205e810b9da9dab5482b805 = $this->env->getExtension("native_profiler");
        $__internal_837554ae43a4a41c0123fe2b8bf42286e9bb3a561205e810b9da9dab5482b805->enter($__internal_837554ae43a4a41c0123fe2b8bf42286e9bb3a561205e810b9da9dab5482b805_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "
  <h2>Ajouter une annonce</h2>

  ";
        // line 9
        echo twig_include($this->env, $context, "OCPlatformBundle:Default:form.html.twig");
        echo "

  <p>
    Attention : cette annonce sera ajoutée directement
    sur la page d'accueil après validation du formulaire.
  </p>

";
        
        $__internal_837554ae43a4a41c0123fe2b8bf42286e9bb3a561205e810b9da9dab5482b805->leave($__internal_837554ae43a4a41c0123fe2b8bf42286e9bb3a561205e810b9da9dab5482b805_prof);

    }

    public function getTemplateName()
    {
        return "OCPlatformBundle:Default:add.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  45 => 9,  40 => 6,  34 => 5,  11 => 3,);
    }
}
/* {# src/OC/PlatformBundle/Resources/views/Default/add.html.twig #}*/
/* */
/* {% extends "OCPlatformBundle::layout.html.twig" %}*/
/* */
/* {% block body %}*/
/* */
/*   <h2>Ajouter une annonce</h2>*/
/* */
/*   {{ include("OCPlatformBundle:Default:form.html.twig") }}*/
/* */
/*   <p>*/
/*     Attention : cette annonce sera ajoutée directement*/
/*     sur la page d'accueil après validation du formulaire.*/
/*   </p>*/
/* */
/* {% endblock %}*/
