<?php

/* @OCPlatform/Advert/menu.html.twig */
class __TwigTemplate_2e849a1fb5122c7300161681eead11dc8a695c2fc22b1e810e33dea630d72e82 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_eb920ff8694e5e44d38f8c88da5c7d31a5f998824d84a197e43bc242e35f5b61 = $this->env->getExtension("native_profiler");
        $__internal_eb920ff8694e5e44d38f8c88da5c7d31a5f998824d84a197e43bc242e35f5b61->enter($__internal_eb920ff8694e5e44d38f8c88da5c7d31a5f998824d84a197e43bc242e35f5b61_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@OCPlatform/Advert/menu.html.twig"));

        // line 2
        echo "
<ul class=\"nav nav-pills nav-stacked\">
  ";
        // line 4
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["listAdverts"]) ? $context["listAdverts"] : $this->getContext($context, "listAdverts")));
        foreach ($context['_seq'] as $context["_key"] => $context["advert"]) {
            // line 5
            echo "    <li>
      <a href=\"";
            // line 6
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("oc_platform_view", array("id" => $this->getAttribute($context["advert"], "id", array()))), "html", null, true);
            echo "\">
        ";
            // line 7
            echo twig_escape_filter($this->env, $this->getAttribute($context["advert"], "title", array()), "html", null, true);
            echo "
      </a>
    </li>
  ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['advert'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 11
        echo "</ul>";
        
        $__internal_eb920ff8694e5e44d38f8c88da5c7d31a5f998824d84a197e43bc242e35f5b61->leave($__internal_eb920ff8694e5e44d38f8c88da5c7d31a5f998824d84a197e43bc242e35f5b61_prof);

    }

    public function getTemplateName()
    {
        return "@OCPlatform/Advert/menu.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  47 => 11,  37 => 7,  33 => 6,  30 => 5,  26 => 4,  22 => 2,);
    }
}
/* {# src/OC/PlatformBundle/Resources/views/Default/menu.html.twig #}*/
/* */
/* <ul class="nav nav-pills nav-stacked">*/
/*   {% for advert in listAdverts %}*/
/*     <li>*/
/*       <a href="{{ path('oc_platform_view', {'id': advert.id}) }}">*/
/*         {{ advert.title }}*/
/*       </a>*/
/*     </li>*/
/*   {% endfor %}*/
/* </ul>*/
