<?php

/* @Framework/Form/choice_widget.html.php */
class __TwigTemplate_43370fd8de0f201025d48f18bf3dc29fec0214a552ced12947e8c3aff4e3f16f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b531d3ad1afc5d5b272d994e57ba2f38b4545713b48cff8bf3887b69bc97a32d = $this->env->getExtension("native_profiler");
        $__internal_b531d3ad1afc5d5b272d994e57ba2f38b4545713b48cff8bf3887b69bc97a32d->enter($__internal_b531d3ad1afc5d5b272d994e57ba2f38b4545713b48cff8bf3887b69bc97a32d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget.html.php"));

        // line 1
        echo "<?php if (\$expanded): ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_expanded') ?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_collapsed') ?>
<?php endif ?>
";
        
        $__internal_b531d3ad1afc5d5b272d994e57ba2f38b4545713b48cff8bf3887b69bc97a32d->leave($__internal_b531d3ad1afc5d5b272d994e57ba2f38b4545713b48cff8bf3887b69bc97a32d_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if ($expanded): ?>*/
/* <?php echo $view['form']->block($form, 'choice_widget_expanded') ?>*/
/* <?php else: ?>*/
/* <?php echo $view['form']->block($form, 'choice_widget_collapsed') ?>*/
/* <?php endif ?>*/
/* */
