<?php

/* TwigBundle:Exception:error.js.twig */
class __TwigTemplate_1e0303274026c6998b255a7c3d969b8ee251517e5970e4f69e4b11726354274d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5aae2382f8f99caf98f03f223beb1f973a434e8aef4a627c461ac94d70cbdbd7 = $this->env->getExtension("native_profiler");
        $__internal_5aae2382f8f99caf98f03f223beb1f973a434e8aef4a627c461ac94d70cbdbd7->enter($__internal_5aae2382f8f99caf98f03f223beb1f973a434e8aef4a627c461ac94d70cbdbd7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "js", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "js", null, true);
        echo "

*/
";
        
        $__internal_5aae2382f8f99caf98f03f223beb1f973a434e8aef4a627c461ac94d70cbdbd7->leave($__internal_5aae2382f8f99caf98f03f223beb1f973a434e8aef4a627c461ac94d70cbdbd7_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 2,  22 => 1,);
    }
}
/* /**/
/* {{ status_code }} {{ status_text }}*/
/* */
/* *//* */
/* */
