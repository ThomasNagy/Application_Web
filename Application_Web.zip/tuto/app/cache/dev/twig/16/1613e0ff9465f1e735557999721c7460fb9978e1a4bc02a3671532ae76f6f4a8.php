<?php

/* @OCPlatform/layout.html.twig */
class __TwigTemplate_d0aa8a9602b7cc7195b205f0bed1469768ebb8182aa4401016ad6290206caf4b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 3
        $this->parent = $this->loadTemplate("::layout.html.twig", "@OCPlatform/layout.html.twig", 3);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'ocplatform_body' => array($this, 'block_ocplatform_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_82b790b36da8a337fc96e251bf135fd332aa7e7fa973faba5aac5cd6f413358d = $this->env->getExtension("native_profiler");
        $__internal_82b790b36da8a337fc96e251bf135fd332aa7e7fa973faba5aac5cd6f413358d->enter($__internal_82b790b36da8a337fc96e251bf135fd332aa7e7fa973faba5aac5cd6f413358d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@OCPlatform/layout.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_82b790b36da8a337fc96e251bf135fd332aa7e7fa973faba5aac5cd6f413358d->leave($__internal_82b790b36da8a337fc96e251bf135fd332aa7e7fa973faba5aac5cd6f413358d_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_e56234db8f18f740e526d8bb43b63eeca1e8b56e13b3e025a86437349b70500c = $this->env->getExtension("native_profiler");
        $__internal_e56234db8f18f740e526d8bb43b63eeca1e8b56e13b3e025a86437349b70500c->enter($__internal_e56234db8f18f740e526d8bb43b63eeca1e8b56e13b3e025a86437349b70500c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 6
        echo "  Annonces - ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
        
        $__internal_e56234db8f18f740e526d8bb43b63eeca1e8b56e13b3e025a86437349b70500c->leave($__internal_e56234db8f18f740e526d8bb43b63eeca1e8b56e13b3e025a86437349b70500c_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_51bc8dfa31519e2b041e22fe1d7d7fcd4d30411c48a2438f74c7e2ed54243d9a = $this->env->getExtension("native_profiler");
        $__internal_51bc8dfa31519e2b041e22fe1d7d7fcd4d30411c48a2438f74c7e2ed54243d9a->enter($__internal_51bc8dfa31519e2b041e22fe1d7d7fcd4d30411c48a2438f74c7e2ed54243d9a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "
  ";
        // line 12
        echo "  <h1>Annonces</h1>

  <hr>

  ";
        // line 17
        echo "  ";
        $this->displayBlock('ocplatform_body', $context, $blocks);
        // line 19
        echo "
";
        
        $__internal_51bc8dfa31519e2b041e22fe1d7d7fcd4d30411c48a2438f74c7e2ed54243d9a->leave($__internal_51bc8dfa31519e2b041e22fe1d7d7fcd4d30411c48a2438f74c7e2ed54243d9a_prof);

    }

    // line 17
    public function block_ocplatform_body($context, array $blocks = array())
    {
        $__internal_8abf11a6aab2945a10c40e5d094f4d1ec0fe59b0d6ea4f7186696fad7f7a987d = $this->env->getExtension("native_profiler");
        $__internal_8abf11a6aab2945a10c40e5d094f4d1ec0fe59b0d6ea4f7186696fad7f7a987d->enter($__internal_8abf11a6aab2945a10c40e5d094f4d1ec0fe59b0d6ea4f7186696fad7f7a987d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ocplatform_body"));

        // line 18
        echo "  ";
        
        $__internal_8abf11a6aab2945a10c40e5d094f4d1ec0fe59b0d6ea4f7186696fad7f7a987d->leave($__internal_8abf11a6aab2945a10c40e5d094f4d1ec0fe59b0d6ea4f7186696fad7f7a987d_prof);

    }

    public function getTemplateName()
    {
        return "@OCPlatform/layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  84 => 18,  78 => 17,  70 => 19,  67 => 17,  61 => 12,  58 => 10,  52 => 9,  42 => 6,  36 => 5,  11 => 3,);
    }
}
/* {# src/OC/PlatformBundle/Resources/views/layout.html.twig #}*/
/* */
/* {% extends "::layout.html.twig" %}*/
/* */
/* {% block title %}*/
/*   Annonces - {{ parent() }}*/
/* {% endblock %}*/
/* */
/* {% block body %}*/
/* */
/*   {# On définit un sous-titre commun à toutes les pages du bundle, par exemple #}*/
/*   <h1>Annonces</h1>*/
/* */
/*   <hr>*/
/* */
/*   {# On définit un nouveau bloc, que les vues du bundle pourront remplir #}*/
/*   {% block ocplatform_body %}*/
/*   {% endblock %}*/
/* */
/* {% endblock %}*/
/* */
