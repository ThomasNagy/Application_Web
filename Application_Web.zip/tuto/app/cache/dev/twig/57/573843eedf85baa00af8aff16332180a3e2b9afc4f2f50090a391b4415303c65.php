<?php

/* TwigBundle:Exception:error.css.twig */
class __TwigTemplate_34374010e628f28d48389f629b351cec98de85bf220fff4412c8bb12e0829942 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_90ca2a74ef75e1a2dcc7ebf1a846b925dc46a37c4d35d45e6f0ada64804a6319 = $this->env->getExtension("native_profiler");
        $__internal_90ca2a74ef75e1a2dcc7ebf1a846b925dc46a37c4d35d45e6f0ada64804a6319->enter($__internal_90ca2a74ef75e1a2dcc7ebf1a846b925dc46a37c4d35d45e6f0ada64804a6319_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "css", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "css", null, true);
        echo "

*/
";
        
        $__internal_90ca2a74ef75e1a2dcc7ebf1a846b925dc46a37c4d35d45e6f0ada64804a6319->leave($__internal_90ca2a74ef75e1a2dcc7ebf1a846b925dc46a37c4d35d45e6f0ada64804a6319_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 2,  22 => 1,);
    }
}
/* /**/
/* {{ status_code }} {{ status_text }}*/
/* */
/* *//* */
/* */
