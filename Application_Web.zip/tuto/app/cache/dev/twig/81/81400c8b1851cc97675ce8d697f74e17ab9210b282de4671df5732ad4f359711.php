<?php

/* OCPlatformBundle:Default:index.html.twig */
class __TwigTemplate_bc1dd2127b027e4e4f78ca82c38dfb5803463473b018e73d373e1728688ea57a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 3
        $this->parent = $this->loadTemplate("OCPlatformBundle::layout.html.twig", "OCPlatformBundle:Default:index.html.twig", 3);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'ocplatform_body' => array($this, 'block_ocplatform_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "OCPlatformBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_df1411baa7cb40b0cea26e7f52e1c13cbab74dd317307e79eecc2df93d27d73d = $this->env->getExtension("native_profiler");
        $__internal_df1411baa7cb40b0cea26e7f52e1c13cbab74dd317307e79eecc2df93d27d73d->enter($__internal_df1411baa7cb40b0cea26e7f52e1c13cbab74dd317307e79eecc2df93d27d73d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle:Default:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_df1411baa7cb40b0cea26e7f52e1c13cbab74dd317307e79eecc2df93d27d73d->leave($__internal_df1411baa7cb40b0cea26e7f52e1c13cbab74dd317307e79eecc2df93d27d73d_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_3000ccfc4f1e17cb75408d5bc9c24aa548ec2f08714e86e2717f83de1872e3c6 = $this->env->getExtension("native_profiler");
        $__internal_3000ccfc4f1e17cb75408d5bc9c24aa548ec2f08714e86e2717f83de1872e3c6->enter($__internal_3000ccfc4f1e17cb75408d5bc9c24aa548ec2f08714e86e2717f83de1872e3c6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 6
        echo "  Accueil - ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
        
        $__internal_3000ccfc4f1e17cb75408d5bc9c24aa548ec2f08714e86e2717f83de1872e3c6->leave($__internal_3000ccfc4f1e17cb75408d5bc9c24aa548ec2f08714e86e2717f83de1872e3c6_prof);

    }

    // line 9
    public function block_ocplatform_body($context, array $blocks = array())
    {
        $__internal_97c7b7baa0fa56560163f1d6df1c09b3a0d9d1dd3cb4e4064f6c0bca69f08860 = $this->env->getExtension("native_profiler");
        $__internal_97c7b7baa0fa56560163f1d6df1c09b3a0d9d1dd3cb4e4064f6c0bca69f08860->enter($__internal_97c7b7baa0fa56560163f1d6df1c09b3a0d9d1dd3cb4e4064f6c0bca69f08860_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ocplatform_body"));

        // line 10
        echo "
  <h2>Liste des annonces</h2>

  <ul>
    ";
        // line 14
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["listAdverts"]) ? $context["listAdverts"] : $this->getContext($context, "listAdverts")));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["advert"]) {
            // line 15
            echo "      <li>
        <a href=\"";
            // line 16
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("oc_platform_view", array("id" => $this->getAttribute($context["advert"], "id", array()))), "html", null, true);
            echo "\">
          ";
            // line 17
            echo twig_escape_filter($this->env, $this->getAttribute($context["advert"], "title", array()), "html", null, true);
            echo "
        </a>
        par ";
            // line 19
            echo twig_escape_filter($this->env, $this->getAttribute($context["advert"], "author", array()), "html", null, true);
            echo ",
        le ";
            // line 20
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["advert"], "date", array()), "d/m/Y"), "html", null, true);
            echo "
      </li>
    ";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 23
            echo "      <li>Pas (encore !) d'annonces</li>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['advert'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 25
        echo "  </ul>
  <ul class=\"pagination\">
  ";
        // line 28
        echo "  ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(range(1, (isset($context["nbPages"]) ? $context["nbPages"] : $this->getContext($context, "nbPages"))));
        foreach ($context['_seq'] as $context["_key"] => $context["p"]) {
            // line 29
            echo "    <li";
            if (($context["p"] == (isset($context["page"]) ? $context["page"] : $this->getContext($context, "page")))) {
                echo " class=\"active\"";
            }
            echo ">
      <a href=\"";
            // line 30
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("oc_platform_home", array("page" => $context["p"])), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $context["p"], "html", null, true);
            echo "</a>
    </li>
  ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['p'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 33
        echo "</ul

";
        
        $__internal_97c7b7baa0fa56560163f1d6df1c09b3a0d9d1dd3cb4e4064f6c0bca69f08860->leave($__internal_97c7b7baa0fa56560163f1d6df1c09b3a0d9d1dd3cb4e4064f6c0bca69f08860_prof);

    }

    public function getTemplateName()
    {
        return "OCPlatformBundle:Default:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  126 => 33,  115 => 30,  108 => 29,  103 => 28,  99 => 25,  92 => 23,  84 => 20,  80 => 19,  75 => 17,  71 => 16,  68 => 15,  63 => 14,  57 => 10,  51 => 9,  41 => 6,  35 => 5,  11 => 3,);
    }
}
/* {# src/OC/PlatformBundle/Resources/views/Default/index.html.twig #}*/
/* */
/* {% extends "OCPlatformBundle::layout.html.twig" %}*/
/* */
/* {% block title %}*/
/*   Accueil - {{ parent() }}*/
/* {% endblock %}*/
/* */
/* {% block ocplatform_body %}*/
/* */
/*   <h2>Liste des annonces</h2>*/
/* */
/*   <ul>*/
/*     {% for advert in listAdverts %}*/
/*       <li>*/
/*         <a href="{{ path('oc_platform_view', {'id': advert.id}) }}">*/
/*           {{ advert.title }}*/
/*         </a>*/
/*         par {{ advert.author }},*/
/*         le {{ advert.date|date('d/m/Y') }}*/
/*       </li>*/
/*     {% else %}*/
/*       <li>Pas (encore !) d'annonces</li>*/
/*     {% endfor %}*/
/*   </ul>*/
/*   <ul class="pagination">*/
/*   {# On utilise la fonction range(a, b) qui crée un tableau de valeurs entre a et b #}*/
/*   {% for p in range(1, nbPages) %}*/
/*     <li{% if p == page %} class="active"{% endif %}>*/
/*       <a href="{{ path('oc_platform_home', {'page': p}) }}">{{ p }}</a>*/
/*     </li>*/
/*   {% endfor %}*/
/* </ul*/
/* */
/* {% endblock %}*/
