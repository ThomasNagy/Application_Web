<?php

/* @Framework/FormTable/hidden_row.html.php */
class __TwigTemplate_4314ef47ecb98d473482a6d87cf60ea07525b0f5eee6a008b454dc4e11e0517e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b5c2004cb22ebd35797177f03884063aeb048993699148787b18d7070c43eab7 = $this->env->getExtension("native_profiler");
        $__internal_b5c2004cb22ebd35797177f03884063aeb048993699148787b18d7070c43eab7->enter($__internal_b5c2004cb22ebd35797177f03884063aeb048993699148787b18d7070c43eab7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/hidden_row.html.php"));

        // line 1
        echo "<tr style=\"display: none\">
    <td colspan=\"2\">
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_b5c2004cb22ebd35797177f03884063aeb048993699148787b18d7070c43eab7->leave($__internal_b5c2004cb22ebd35797177f03884063aeb048993699148787b18d7070c43eab7_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <tr style="display: none">*/
/*     <td colspan="2">*/
/*         <?php echo $view['form']->widget($form) ?>*/
/*     </td>*/
/* </tr>*/
/* */
