<?php

/* @Framework/Form/email_widget.html.php */
class __TwigTemplate_14e61a9d0a93b75f971605a79199004e3d65e39080cba3b92b23706db5d7ab5e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8749713f74865e329a2f7bf9a92efd0332b06b9d321b2582684fa38ce271ac68 = $this->env->getExtension("native_profiler");
        $__internal_8749713f74865e329a2f7bf9a92efd0332b06b9d321b2582684fa38ce271ac68->enter($__internal_8749713f74865e329a2f7bf9a92efd0332b06b9d321b2582684fa38ce271ac68_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/email_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'email')) ?>
";
        
        $__internal_8749713f74865e329a2f7bf9a92efd0332b06b9d321b2582684fa38ce271ac68->leave($__internal_8749713f74865e329a2f7bf9a92efd0332b06b9d321b2582684fa38ce271ac68_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/email_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'email')) ?>*/
/* */
