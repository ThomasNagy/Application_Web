<?php

/* OCPlatformBundle:Default:edit.html.twig */
class __TwigTemplate_9660a4c17763050c22273d5eb19a1762f2cfc4cb01cf3534b2f91a11cf9cff53 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 3
        $this->parent = $this->loadTemplate("OCPlatformBundle::layout.html.twig", "OCPlatformBundle:Default:edit.html.twig", 3);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'ocplatform_body' => array($this, 'block_ocplatform_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "OCPlatformBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fc55d50dfbc4fc600b6ccb4d1be0fd4e5e4330f5ae7bdb34684696cddfef95b1 = $this->env->getExtension("native_profiler");
        $__internal_fc55d50dfbc4fc600b6ccb4d1be0fd4e5e4330f5ae7bdb34684696cddfef95b1->enter($__internal_fc55d50dfbc4fc600b6ccb4d1be0fd4e5e4330f5ae7bdb34684696cddfef95b1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle:Default:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_fc55d50dfbc4fc600b6ccb4d1be0fd4e5e4330f5ae7bdb34684696cddfef95b1->leave($__internal_fc55d50dfbc4fc600b6ccb4d1be0fd4e5e4330f5ae7bdb34684696cddfef95b1_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_62b4c3cbff919a1c453615867d382066bf52cf1607ca5748f317f6e74caf6cc8 = $this->env->getExtension("native_profiler");
        $__internal_62b4c3cbff919a1c453615867d382066bf52cf1607ca5748f317f6e74caf6cc8->enter($__internal_62b4c3cbff919a1c453615867d382066bf52cf1607ca5748f317f6e74caf6cc8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 6
        echo "  Modifier une annonce - ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
        
        $__internal_62b4c3cbff919a1c453615867d382066bf52cf1607ca5748f317f6e74caf6cc8->leave($__internal_62b4c3cbff919a1c453615867d382066bf52cf1607ca5748f317f6e74caf6cc8_prof);

    }

    // line 9
    public function block_ocplatform_body($context, array $blocks = array())
    {
        $__internal_758b6f4fba57718ae47a6b59435b134da6f5633f39f7a5634c21fa483ee68623 = $this->env->getExtension("native_profiler");
        $__internal_758b6f4fba57718ae47a6b59435b134da6f5633f39f7a5634c21fa483ee68623->enter($__internal_758b6f4fba57718ae47a6b59435b134da6f5633f39f7a5634c21fa483ee68623_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ocplatform_body"));

        // line 10
        echo "
  <h2>Modifier une annonce</h2>

  ";
        // line 13
        echo twig_include($this->env, $context, "OCPlatformBundle:Default:form.html.twig");
        echo "

  <p>
    Vous éditez une annonce déjà existante, merci de ne pas changer
    l'esprit générale de l'annonce déjà publiée.
  </p>

  <p>
    <a href=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("oc_platform_view", array("id" => $this->getAttribute((isset($context["advert"]) ? $context["advert"] : $this->getContext($context, "advert")), "id", array()))), "html", null, true);
        echo "\" class=\"btn btn-default\">
      <i class=\"glyphicon glyphicon-chevron-left\"></i>
      Retour à l'annonce
    </a>
  </p>

";
        
        $__internal_758b6f4fba57718ae47a6b59435b134da6f5633f39f7a5634c21fa483ee68623->leave($__internal_758b6f4fba57718ae47a6b59435b134da6f5633f39f7a5634c21fa483ee68623_prof);

    }

    public function getTemplateName()
    {
        return "OCPlatformBundle:Default:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 21,  62 => 13,  57 => 10,  51 => 9,  41 => 6,  35 => 5,  11 => 3,);
    }
}
/* {# src/OC/PlatformBundle/Resources/views/Default/edit.html.twig #}*/
/* */
/* {% extends "OCPlatformBundle::layout.html.twig" %}*/
/* */
/* {% block title %}*/
/*   Modifier une annonce - {{ parent() }}*/
/* {% endblock %}*/
/* */
/* {% block ocplatform_body %}*/
/* */
/*   <h2>Modifier une annonce</h2>*/
/* */
/*   {{ include("OCPlatformBundle:Default:form.html.twig") }}*/
/* */
/*   <p>*/
/*     Vous éditez une annonce déjà existante, merci de ne pas changer*/
/*     l'esprit générale de l'annonce déjà publiée.*/
/*   </p>*/
/* */
/*   <p>*/
/*     <a href="{{ path('oc_platform_view', {'id': advert.id}) }}" class="btn btn-default">*/
/*       <i class="glyphicon glyphicon-chevron-left"></i>*/
/*       Retour à l'annonce*/
/*     </a>*/
/*   </p>*/
/* */
/* {% endblock %}*/
