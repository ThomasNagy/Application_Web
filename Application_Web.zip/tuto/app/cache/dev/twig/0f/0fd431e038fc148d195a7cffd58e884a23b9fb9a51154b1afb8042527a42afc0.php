<?php

/* TwigBundle:Exception:error.json.twig */
class __TwigTemplate_deaa032a77fafd73f19f06b44622bc2e52bf6da5b0f9eb3efa12ec7362840917 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8c6fe542750d810c006dc084821f8fe42cc06ccf67ea540bba66612097c75a02 = $this->env->getExtension("native_profiler");
        $__internal_8c6fe542750d810c006dc084821f8fe42cc06ccf67ea540bba66612097c75a02->enter($__internal_8c6fe542750d810c006dc084821f8fe42cc06ccf67ea540bba66612097c75a02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "message" => (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")))));
        echo "
";
        
        $__internal_8c6fe542750d810c006dc084821f8fe42cc06ccf67ea540bba66612097c75a02->leave($__internal_8c6fe542750d810c006dc084821f8fe42cc06ccf67ea540bba66612097c75a02_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {{ { 'error': { 'code': status_code, 'message': status_text } }|json_encode|raw }}*/
/* */
