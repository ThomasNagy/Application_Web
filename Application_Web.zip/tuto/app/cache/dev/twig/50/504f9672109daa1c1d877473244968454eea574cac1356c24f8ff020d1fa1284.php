<?php

/* @Framework/Form/datetime_widget.html.php */
class __TwigTemplate_93e35c26ff972c4f80c38fc3657f420d01837780e322100eb4d38119d848c912 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b588dd34434e93e0fd0af65e06c7eb3ebf5e02c0c372322425d6c1d7832052e9 = $this->env->getExtension("native_profiler");
        $__internal_b588dd34434e93e0fd0af65e06c7eb3ebf5e02c0c372322425d6c1d7832052e9->enter($__internal_b588dd34434e93e0fd0af65e06c7eb3ebf5e02c0c372322425d6c1d7832052e9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/datetime_widget.html.php"));

        // line 1
        echo "<?php if (\$widget == 'single_text'): ?>
    <?php echo \$view['form']->block(\$form, 'form_widget_simple'); ?>
<?php else: ?>
    <div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
        <?php echo \$view['form']->widget(\$form['date']).' '.\$view['form']->widget(\$form['time']) ?>
    </div>
<?php endif ?>
";
        
        $__internal_b588dd34434e93e0fd0af65e06c7eb3ebf5e02c0c372322425d6c1d7832052e9->leave($__internal_b588dd34434e93e0fd0af65e06c7eb3ebf5e02c0c372322425d6c1d7832052e9_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/datetime_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if ($widget == 'single_text'): ?>*/
/*     <?php echo $view['form']->block($form, 'form_widget_simple'); ?>*/
/* <?php else: ?>*/
/*     <div <?php echo $view['form']->block($form, 'widget_container_attributes') ?>>*/
/*         <?php echo $view['form']->widget($form['date']).' '.$view['form']->widget($form['time']) ?>*/
/*     </div>*/
/* <?php endif ?>*/
/* */
