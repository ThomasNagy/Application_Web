<?php

/* @WebProfiler/Profiler/header.html.twig */
class __TwigTemplate_a368ff66810b0b89c94551e368d390be1847cdcb139a5614265953d9235d1288 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bcbd4347f24fd4cb5bb4ec44741543ad2cf7990ac07ab810cf8ae0c789cb9ed4 = $this->env->getExtension("native_profiler");
        $__internal_bcbd4347f24fd4cb5bb4ec44741543ad2cf7990ac07ab810cf8ae0c789cb9ed4->enter($__internal_bcbd4347f24fd4cb5bb4ec44741543ad2cf7990ac07ab810cf8ae0c789cb9ed4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/header.html.twig"));

        // line 1
        echo "<div id=\"header\">
    <div class=\"container\">
        <h1>";
        // line 3
        echo twig_include($this->env, $context, "@WebProfiler/Icon/symfony.svg");
        echo " Symfony <span>Profiler</span></h1>

        <div class=\"search\">
            <form method=\"get\" action=\"https://symfony.com/search\" target=\"_blank\">
                <div class=\"form-row\">
                    <input name=\"q\" id=\"search-id\" type=\"search\" placeholder=\"search on symfony.com\">
                    <button type=\"submit\" class=\"btn\">Search</button>
                </div>
           </form>
        </div>
    </div>
</div>
";
        
        $__internal_bcbd4347f24fd4cb5bb4ec44741543ad2cf7990ac07ab810cf8ae0c789cb9ed4->leave($__internal_bcbd4347f24fd4cb5bb4ec44741543ad2cf7990ac07ab810cf8ae0c789cb9ed4_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/header.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  26 => 3,  22 => 1,);
    }
}
/* <div id="header">*/
/*     <div class="container">*/
/*         <h1>{{ include('@WebProfiler/Icon/symfony.svg') }} Symfony <span>Profiler</span></h1>*/
/* */
/*         <div class="search">*/
/*             <form method="get" action="https://symfony.com/search" target="_blank">*/
/*                 <div class="form-row">*/
/*                     <input name="q" id="search-id" type="search" placeholder="search on symfony.com">*/
/*                     <button type="submit" class="btn">Search</button>*/
/*                 </div>*/
/*            </form>*/
/*         </div>*/
/*     </div>*/
/* </div>*/
/* */
