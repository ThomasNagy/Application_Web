<?php

/* @Framework/Form/attributes.html.php */
class __TwigTemplate_a04cf774e5b9d2fa90b8948ea6b987506ce5771fe3fe6f5a495ea53f2ab7adcd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_37448f174e18f3ddaafe864d1e5b590b4cf628c6e0fd2cafcfa07c2a7f2e44a5 = $this->env->getExtension("native_profiler");
        $__internal_37448f174e18f3ddaafe864d1e5b590b4cf628c6e0fd2cafcfa07c2a7f2e44a5->enter($__internal_37448f174e18f3ddaafe864d1e5b590b4cf628c6e0fd2cafcfa07c2a7f2e44a5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
";
        
        $__internal_37448f174e18f3ddaafe864d1e5b590b4cf628c6e0fd2cafcfa07c2a7f2e44a5->leave($__internal_37448f174e18f3ddaafe864d1e5b590b4cf628c6e0fd2cafcfa07c2a7f2e44a5_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'widget_attributes') ?>*/
/* */
