<?php

/* OCPlatformBundle:Advert:form.html.twig */
class __TwigTemplate_14f3669c02c61b860f3956e1db5fe79b0827c9b699bf859be136b7f7f850865a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_609b0a9830ed19268bacbde7f0b581e73009e5d86df2581d583ea50482c630ad = $this->env->getExtension("native_profiler");
        $__internal_609b0a9830ed19268bacbde7f0b581e73009e5d86df2581d583ea50482c630ad->enter($__internal_609b0a9830ed19268bacbde7f0b581e73009e5d86df2581d583ea50482c630ad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle:Advert:form.html.twig"));

        // line 2
        echo "
<h3>Formulaire d'annonce</h3>

";
        // line 7
        echo "<div class=\"well\">
  Ici se trouvera le formulaire.
</div>";
        
        $__internal_609b0a9830ed19268bacbde7f0b581e73009e5d86df2581d583ea50482c630ad->leave($__internal_609b0a9830ed19268bacbde7f0b581e73009e5d86df2581d583ea50482c630ad_prof);

    }

    public function getTemplateName()
    {
        return "OCPlatformBundle:Advert:form.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  27 => 7,  22 => 2,);
    }
}
/* {# src/OC/PlatformBundle/Resources/views/Default/form.html.twig #}*/
/* */
/* <h3>Formulaire d'annonce</h3>*/
/* */
/* {# On laisse vide la vue pour l'instant, on la comblera plus tard*/
/*    lorsqu'on saura afficher un formulaire. #}*/
/* <div class="well">*/
/*   Ici se trouvera le formulaire.*/
/* </div>*/
