<?php

/* @Twig/Exception/exception.rdf.twig */
class __TwigTemplate_254024ae055e250c8fad60d51ef34ab64276fc0ed6a493bd1ea0773bb031400d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_dd1e932f876d0eff95b7f801d6e1c9517acd410649c49c857992a5994e74e180 = $this->env->getExtension("native_profiler");
        $__internal_dd1e932f876d0eff95b7f801d6e1c9517acd410649c49c857992a5994e74e180->enter($__internal_dd1e932f876d0eff95b7f801d6e1c9517acd410649c49c857992a5994e74e180_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/exception.xml.twig", "@Twig/Exception/exception.rdf.twig", 1)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        
        $__internal_dd1e932f876d0eff95b7f801d6e1c9517acd410649c49c857992a5994e74e180->leave($__internal_dd1e932f876d0eff95b7f801d6e1c9517acd410649c49c857992a5994e74e180_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/exception.xml.twig' with { 'exception': exception } %}*/
/* */
