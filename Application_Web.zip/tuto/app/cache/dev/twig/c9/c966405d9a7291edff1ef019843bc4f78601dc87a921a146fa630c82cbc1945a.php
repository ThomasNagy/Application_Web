<?php

/* @Framework/Form/checkbox_widget.html.php */
class __TwigTemplate_e7d1fd02ec2913cab999a2703b4dee696a8325f96749b27e03d8cee60bdd731f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a0a165dd65305d1c64c90464f2e7a2d59317ca9078cb54adc87b7dff427de673 = $this->env->getExtension("native_profiler");
        $__internal_a0a165dd65305d1c64c90464f2e7a2d59317ca9078cb54adc87b7dff427de673->enter($__internal_a0a165dd65305d1c64c90464f2e7a2d59317ca9078cb54adc87b7dff427de673_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/checkbox_widget.html.php"));

        // line 1
        echo "<input type=\"checkbox\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    <?php if (strlen(\$value) > 0): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?>
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_a0a165dd65305d1c64c90464f2e7a2d59317ca9078cb54adc87b7dff427de673->leave($__internal_a0a165dd65305d1c64c90464f2e7a2d59317ca9078cb54adc87b7dff427de673_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/checkbox_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <input type="checkbox"*/
/*     <?php echo $view['form']->block($form, 'widget_attributes') ?>*/
/*     <?php if (strlen($value) > 0): ?> value="<?php echo $view->escape($value) ?>"<?php endif ?>*/
/*     <?php if ($checked): ?> checked="checked"<?php endif ?>*/
/* />*/
/* */
