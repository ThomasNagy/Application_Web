<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_652efcae8437d9387a64284b573a3e42c07b5958d2fb54ebea0ed2af76bed15d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f8bdc8baf4b6f89f09dbb7c164a227ebce189b991e6d8d53c377fda057cee579 = $this->env->getExtension("native_profiler");
        $__internal_f8bdc8baf4b6f89f09dbb7c164a227ebce189b991e6d8d53c377fda057cee579->enter($__internal_f8bdc8baf4b6f89f09dbb7c164a227ebce189b991e6d8d53c377fda057cee579_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_f8bdc8baf4b6f89f09dbb7c164a227ebce189b991e6d8d53c377fda057cee579->leave($__internal_f8bdc8baf4b6f89f09dbb7c164a227ebce189b991e6d8d53c377fda057cee579_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_4a50dbc2655be8db731083c0cbd718bb3a9fd5cd54501f75e888ab33a7800b76 = $this->env->getExtension("native_profiler");
        $__internal_4a50dbc2655be8db731083c0cbd718bb3a9fd5cd54501f75e888ab33a7800b76->enter($__internal_4a50dbc2655be8db731083c0cbd718bb3a9fd5cd54501f75e888ab33a7800b76_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_4a50dbc2655be8db731083c0cbd718bb3a9fd5cd54501f75e888ab33a7800b76->leave($__internal_4a50dbc2655be8db731083c0cbd718bb3a9fd5cd54501f75e888ab33a7800b76_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }
}
/* {% block panel '' %}*/
/* */
