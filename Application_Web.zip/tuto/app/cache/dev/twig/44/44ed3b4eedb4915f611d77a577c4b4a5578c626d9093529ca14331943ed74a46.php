<?php

/* @Framework/FormTable/form_row.html.php */
class __TwigTemplate_2794eb65308f5dfb30ec90057db0567e52f235b92a51537fe98395e14b7528d6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f947d007f765715168382444ea69926ed04a2001d012e28190b0d10a0567f6cc = $this->env->getExtension("native_profiler");
        $__internal_f947d007f765715168382444ea69926ed04a2001d012e28190b0d10a0567f6cc->enter($__internal_f947d007f765715168382444ea69926ed04a2001d012e28190b0d10a0567f6cc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_row.html.php"));

        // line 1
        echo "<tr>
    <td>
        <?php echo \$view['form']->label(\$form) ?>
    </td>
    <td>
        <?php echo \$view['form']->errors(\$form) ?>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_f947d007f765715168382444ea69926ed04a2001d012e28190b0d10a0567f6cc->leave($__internal_f947d007f765715168382444ea69926ed04a2001d012e28190b0d10a0567f6cc_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <tr>*/
/*     <td>*/
/*         <?php echo $view['form']->label($form) ?>*/
/*     </td>*/
/*     <td>*/
/*         <?php echo $view['form']->errors($form) ?>*/
/*         <?php echo $view['form']->widget($form) ?>*/
/*     </td>*/
/* </tr>*/
/* */
