<?php

/* @Twig/Exception/exception.atom.twig */
class __TwigTemplate_f4f2214679df3079279c9a57a2ec09981cdbbf4deb21600cb92592e0f609e52e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ca7638861b65280a1c7cc2d8d3effd2e3a007e1cbbfa6da647319d3934f0a9b0 = $this->env->getExtension("native_profiler");
        $__internal_ca7638861b65280a1c7cc2d8d3effd2e3a007e1cbbfa6da647319d3934f0a9b0->enter($__internal_ca7638861b65280a1c7cc2d8d3effd2e3a007e1cbbfa6da647319d3934f0a9b0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/exception.xml.twig", "@Twig/Exception/exception.atom.twig", 1)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        
        $__internal_ca7638861b65280a1c7cc2d8d3effd2e3a007e1cbbfa6da647319d3934f0a9b0->leave($__internal_ca7638861b65280a1c7cc2d8d3effd2e3a007e1cbbfa6da647319d3934f0a9b0_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/exception.xml.twig' with { 'exception': exception } %}*/
/* */
