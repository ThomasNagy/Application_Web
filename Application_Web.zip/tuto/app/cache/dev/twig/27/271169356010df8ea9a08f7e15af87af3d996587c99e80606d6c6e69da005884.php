<?php

/* @Framework/Form/button_row.html.php */
class __TwigTemplate_fbd965dd43bae0b346c691c9124eeae84c6f537982b852433d9a1757528df046 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f5b766f47c8e4532e4ef0b857344b3f456f1f2830ada8a3fab2c8be00271706a = $this->env->getExtension("native_profiler");
        $__internal_f5b766f47c8e4532e4ef0b857344b3f456f1f2830ada8a3fab2c8be00271706a->enter($__internal_f5b766f47c8e4532e4ef0b857344b3f456f1f2830ada8a3fab2c8be00271706a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_f5b766f47c8e4532e4ef0b857344b3f456f1f2830ada8a3fab2c8be00271706a->leave($__internal_f5b766f47c8e4532e4ef0b857344b3f456f1f2830ada8a3fab2c8be00271706a_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div>*/
/*     <?php echo $view['form']->widget($form) ?>*/
/* </div>*/
/* */
