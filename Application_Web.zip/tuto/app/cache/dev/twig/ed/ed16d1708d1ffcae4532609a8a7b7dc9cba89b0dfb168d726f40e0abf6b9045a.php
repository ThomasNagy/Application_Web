<?php

/* @Framework/Form/reset_widget.html.php */
class __TwigTemplate_3b74805095b29ee80dc9afb3ca1fddb3b4207e56a17c6da31ea749a05fb9f07e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6465bfbfa0095d0b1f43658e9550bb0ffca43f96b42f659c11465f7d67e34c7a = $this->env->getExtension("native_profiler");
        $__internal_6465bfbfa0095d0b1f43658e9550bb0ffca43f96b42f659c11465f7d67e34c7a->enter($__internal_6465bfbfa0095d0b1f43658e9550bb0ffca43f96b42f659c11465f7d67e34c7a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget',  array('type' => isset(\$type) ? \$type : 'reset')) ?>
";
        
        $__internal_6465bfbfa0095d0b1f43658e9550bb0ffca43f96b42f659c11465f7d67e34c7a->leave($__internal_6465bfbfa0095d0b1f43658e9550bb0ffca43f96b42f659c11465f7d67e34c7a_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/reset_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'button_widget',  array('type' => isset($type) ? $type : 'reset')) ?>*/
/* */
