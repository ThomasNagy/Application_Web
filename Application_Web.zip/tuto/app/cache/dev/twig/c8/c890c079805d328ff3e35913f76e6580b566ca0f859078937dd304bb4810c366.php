<?php

/* @Framework/Form/form_end.html.php */
class __TwigTemplate_52ee16dd344b9fb5cf19ab0b098d97a67599007878d093a5b3e5e2fadf68e31f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e5e7c3903ede2acc7719ac75af21c49c2aa00eb0a59a064407a5c0e411407a2b = $this->env->getExtension("native_profiler");
        $__internal_e5e7c3903ede2acc7719ac75af21c49c2aa00eb0a59a064407a5c0e411407a2b->enter($__internal_e5e7c3903ede2acc7719ac75af21c49c2aa00eb0a59a064407a5c0e411407a2b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_end.html.php"));

        // line 1
        echo "<?php if (!isset(\$render_rest) || \$render_rest): ?>
<?php echo \$view['form']->rest(\$form) ?>
<?php endif ?>
</form>
";
        
        $__internal_e5e7c3903ede2acc7719ac75af21c49c2aa00eb0a59a064407a5c0e411407a2b->leave($__internal_e5e7c3903ede2acc7719ac75af21c49c2aa00eb0a59a064407a5c0e411407a2b_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_end.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if (!isset($render_rest) || $render_rest): ?>*/
/* <?php echo $view['form']->rest($form) ?>*/
/* <?php endif ?>*/
/* </form>*/
/* */
