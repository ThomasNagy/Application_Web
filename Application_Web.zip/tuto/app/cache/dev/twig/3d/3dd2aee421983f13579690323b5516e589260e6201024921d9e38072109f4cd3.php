<?php

/* TwigBundle:Exception:error.rdf.twig */
class __TwigTemplate_83bf6c5b09e0add5c0dd7be5f09a98937792db8d6e666d6f8933b0088763621c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7b2258d28d7990e9d8f81eb690338e58460078d32b88e21efd145ba90f2c4f59 = $this->env->getExtension("native_profiler");
        $__internal_7b2258d28d7990e9d8f81eb690338e58460078d32b88e21efd145ba90f2c4f59->enter($__internal_7b2258d28d7990e9d8f81eb690338e58460078d32b88e21efd145ba90f2c4f59_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "TwigBundle:Exception:error.rdf.twig", 1)->display($context);
        
        $__internal_7b2258d28d7990e9d8f81eb690338e58460078d32b88e21efd145ba90f2c4f59->leave($__internal_7b2258d28d7990e9d8f81eb690338e58460078d32b88e21efd145ba90f2c4f59_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.rdf.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/error.xml.twig' %}*/
/* */
