<?php

/* @Twig/Exception/error.json.twig */
class __TwigTemplate_0bdcab0f77200330c3c0edbcd27503e5eec60b0b97394d8b4c72e9a47df0fb10 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3b976859af34ba31ec14abf89bd196abb53c37dc34b653ca5ea7b905b3039bc6 = $this->env->getExtension("native_profiler");
        $__internal_3b976859af34ba31ec14abf89bd196abb53c37dc34b653ca5ea7b905b3039bc6->enter($__internal_3b976859af34ba31ec14abf89bd196abb53c37dc34b653ca5ea7b905b3039bc6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "message" => (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")))));
        echo "
";
        
        $__internal_3b976859af34ba31ec14abf89bd196abb53c37dc34b653ca5ea7b905b3039bc6->leave($__internal_3b976859af34ba31ec14abf89bd196abb53c37dc34b653ca5ea7b905b3039bc6_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {{ { 'error': { 'code': status_code, 'message': status_text } }|json_encode|raw }}*/
/* */
