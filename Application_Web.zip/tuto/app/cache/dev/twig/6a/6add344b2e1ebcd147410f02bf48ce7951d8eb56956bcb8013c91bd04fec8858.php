<?php

/* @Framework/Form/radio_widget.html.php */
class __TwigTemplate_f457cc76c863136fdbb492b0c3724a05abe4b2931b9642539f2835f6ea82c3e1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a4df2b6ad4d1ab2e7bc6d791a33ff93f11fe5ddec4e8cddc6f2827f2746e5aaa = $this->env->getExtension("native_profiler");
        $__internal_a4df2b6ad4d1ab2e7bc6d791a33ff93f11fe5ddec4e8cddc6f2827f2746e5aaa->enter($__internal_a4df2b6ad4d1ab2e7bc6d791a33ff93f11fe5ddec4e8cddc6f2827f2746e5aaa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/radio_widget.html.php"));

        // line 1
        echo "<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_a4df2b6ad4d1ab2e7bc6d791a33ff93f11fe5ddec4e8cddc6f2827f2746e5aaa->leave($__internal_a4df2b6ad4d1ab2e7bc6d791a33ff93f11fe5ddec4e8cddc6f2827f2746e5aaa_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/radio_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <input type="radio"*/
/*     <?php echo $view['form']->block($form, 'widget_attributes') ?>*/
/*     value="<?php echo $view->escape($value) ?>"*/
/*     <?php if ($checked): ?> checked="checked"<?php endif ?>*/
/* />*/
/* */
