<?php

/* @Twig/Exception/error.xml.twig */
class __TwigTemplate_c86a0bee4f2721a207437420aad2e51338ffe6780602248f987f043b453c41c3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_34316b6de5da0752d108b52123e0f8d0b27abdb5e152be2422c3eec1a55c9410 = $this->env->getExtension("native_profiler");
        $__internal_34316b6de5da0752d108b52123e0f8d0b27abdb5e152be2422c3eec1a55c9410->enter($__internal_34316b6de5da0752d108b52123e0f8d0b27abdb5e152be2422c3eec1a55c9410_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.xml.twig"));

        // line 1
        echo "<?xml version=\"1.0\" encoding=\"";
        echo twig_escape_filter($this->env, $this->env->getCharset(), "html", null, true);
        echo "\" ?>

<error code=\"";
        // line 3
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "html", null, true);
        echo "\" message=\"";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "html", null, true);
        echo "\" />
";
        
        $__internal_34316b6de5da0752d108b52123e0f8d0b27abdb5e152be2422c3eec1a55c9410->leave($__internal_34316b6de5da0752d108b52123e0f8d0b27abdb5e152be2422c3eec1a55c9410_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.xml.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 3,  22 => 1,);
    }
}
/* <?xml version="1.0" encoding="{{ _charset }}" ?>*/
/* */
/* <error code="{{ status_code }}" message="{{ status_text }}" />*/
/* */
