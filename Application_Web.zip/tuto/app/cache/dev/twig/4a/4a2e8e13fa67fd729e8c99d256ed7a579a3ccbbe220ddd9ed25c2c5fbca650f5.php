<?php

/* @Framework/Form/collection_widget.html.php */
class __TwigTemplate_e1c2e1150cbca32b4c04bd49af03be91c70d22d76ae031b21c682ec67fa60688 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3075458aceee2ceac81b854ac6e1d75a21e717e39ef4b996135bc490f30b5b4b = $this->env->getExtension("native_profiler");
        $__internal_3075458aceee2ceac81b854ac6e1d75a21e717e39ef4b996135bc490f30b5b4b->enter($__internal_3075458aceee2ceac81b854ac6e1d75a21e717e39ef4b996135bc490f30b5b4b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/collection_widget.html.php"));

        // line 1
        echo "<?php if (isset(\$prototype)): ?>
    <?php \$attr['data-prototype'] = \$view->escape(\$view['form']->row(\$prototype)) ?>
<?php endif ?>
<?php echo \$view['form']->widget(\$form, array('attr' => \$attr)) ?>
";
        
        $__internal_3075458aceee2ceac81b854ac6e1d75a21e717e39ef4b996135bc490f30b5b4b->leave($__internal_3075458aceee2ceac81b854ac6e1d75a21e717e39ef4b996135bc490f30b5b4b_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/collection_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if (isset($prototype)): ?>*/
/*     <?php $attr['data-prototype'] = $view->escape($view['form']->row($prototype)) ?>*/
/* <?php endif ?>*/
/* <?php echo $view['form']->widget($form, array('attr' => $attr)) ?>*/
/* */
