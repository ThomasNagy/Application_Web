<?php

/* @OCPlatform/Advert/index.html.twig */
class __TwigTemplate_b3d6a195ee3ea7ad056e9e0f3e0e016effe0dd14f9bab4796a2add8079e3dadc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e3d24c84ed690deb553b36fcfc52f821c510b818e8eb90f4284ebb8e1f5b310b = $this->env->getExtension("native_profiler");
        $__internal_e3d24c84ed690deb553b36fcfc52f821c510b818e8eb90f4284ebb8e1f5b310b->enter($__internal_e3d24c84ed690deb553b36fcfc52f821c510b818e8eb90f4284ebb8e1f5b310b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@OCPlatform/Advert/index.html.twig"));

        // line 2
        echo "
<!DOCTYPE html>
<html>
    <head>
        <title>Bienvenue sur ma première page avec OpenClassrooms !</title>
    </head>
    <body>
        <h1>Hello World !</h1>
        
        <p>
            Le Hello World est un grand classique en programmation.
            Il signifie énormément, car cela veut dire que vous avez
            réussi à exécuter le programme pour accomplir une tâche simple :
            afficher ce hello world !
        </p>
    </body>
</html>";
        
        $__internal_e3d24c84ed690deb553b36fcfc52f821c510b818e8eb90f4284ebb8e1f5b310b->leave($__internal_e3d24c84ed690deb553b36fcfc52f821c510b818e8eb90f4284ebb8e1f5b310b_prof);

    }

    public function getTemplateName()
    {
        return "@OCPlatform/Advert/index.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 2,);
    }
}
/* {# src/OC/PlatformBundle/Resources/views/Advert/index.html.twig #}*/
/* */
/* <!DOCTYPE html>*/
/* <html>*/
/*     <head>*/
/*         <title>Bienvenue sur ma première page avec OpenClassrooms !</title>*/
/*     </head>*/
/*     <body>*/
/*         <h1>Hello World !</h1>*/
/*         */
/*         <p>*/
/*             Le Hello World est un grand classique en programmation.*/
/*             Il signifie énormément, car cela veut dire que vous avez*/
/*             réussi à exécuter le programme pour accomplir une tâche simple :*/
/*             afficher ce hello world !*/
/*         </p>*/
/*     </body>*/
/* </html>*/
