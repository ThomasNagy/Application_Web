<?php

/* @OCPlatform/Default/index.html.twig */
class __TwigTemplate_f4c559af3f31e023098f3a2043d57277b25c6ce6450c066c9bdecef8c650e1aa extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 3
        $this->parent = $this->loadTemplate("OCPlatformBundle::layout.html.twig", "@OCPlatform/Default/index.html.twig", 3);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'ocplatform_body' => array($this, 'block_ocplatform_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "OCPlatformBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9a8b05b20d511ae80c4752d544ac5a858d62fb5d367042aa997fe251cf09f0b3 = $this->env->getExtension("native_profiler");
        $__internal_9a8b05b20d511ae80c4752d544ac5a858d62fb5d367042aa997fe251cf09f0b3->enter($__internal_9a8b05b20d511ae80c4752d544ac5a858d62fb5d367042aa997fe251cf09f0b3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@OCPlatform/Default/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9a8b05b20d511ae80c4752d544ac5a858d62fb5d367042aa997fe251cf09f0b3->leave($__internal_9a8b05b20d511ae80c4752d544ac5a858d62fb5d367042aa997fe251cf09f0b3_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_07a06881b7bef20837cc5cde614c6bbd4d490f8826ec5c1f6811fa0d0e44caa9 = $this->env->getExtension("native_profiler");
        $__internal_07a06881b7bef20837cc5cde614c6bbd4d490f8826ec5c1f6811fa0d0e44caa9->enter($__internal_07a06881b7bef20837cc5cde614c6bbd4d490f8826ec5c1f6811fa0d0e44caa9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 6
        echo "  Accueil - ";
        $this->displayParentBlock("title", $context, $blocks);
        echo "
";
        
        $__internal_07a06881b7bef20837cc5cde614c6bbd4d490f8826ec5c1f6811fa0d0e44caa9->leave($__internal_07a06881b7bef20837cc5cde614c6bbd4d490f8826ec5c1f6811fa0d0e44caa9_prof);

    }

    // line 9
    public function block_ocplatform_body($context, array $blocks = array())
    {
        $__internal_8a38f086071d5b36f7aeefddb954358012c9c407e1e511ef87d2297be629cee5 = $this->env->getExtension("native_profiler");
        $__internal_8a38f086071d5b36f7aeefddb954358012c9c407e1e511ef87d2297be629cee5->enter($__internal_8a38f086071d5b36f7aeefddb954358012c9c407e1e511ef87d2297be629cee5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ocplatform_body"));

        // line 10
        echo "
  <h2>Liste des annonces</h2>

  <ul>
    ";
        // line 14
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["listAdverts"]) ? $context["listAdverts"] : $this->getContext($context, "listAdverts")));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["advert"]) {
            // line 15
            echo "      <li>
        <a href=\"";
            // line 16
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("oc_platform_view", array("id" => $this->getAttribute($context["advert"], "id", array()))), "html", null, true);
            echo "\">
          ";
            // line 17
            echo twig_escape_filter($this->env, $this->getAttribute($context["advert"], "title", array()), "html", null, true);
            echo "
        </a>
        par ";
            // line 19
            echo twig_escape_filter($this->env, $this->getAttribute($context["advert"], "author", array()), "html", null, true);
            echo ",
        le ";
            // line 20
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["advert"], "date", array()), "d/m/Y"), "html", null, true);
            echo "
      </li>
    ";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 23
            echo "      <li>Pas (encore !) d'annonces</li>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['advert'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 25
        echo "  </ul>

";
        
        $__internal_8a38f086071d5b36f7aeefddb954358012c9c407e1e511ef87d2297be629cee5->leave($__internal_8a38f086071d5b36f7aeefddb954358012c9c407e1e511ef87d2297be629cee5_prof);

    }

    public function getTemplateName()
    {
        return "@OCPlatform/Default/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  99 => 25,  92 => 23,  84 => 20,  80 => 19,  75 => 17,  71 => 16,  68 => 15,  63 => 14,  57 => 10,  51 => 9,  41 => 6,  35 => 5,  11 => 3,);
    }
}
/* {# src/OC/PlatformBundle/Resources/views/Advert/index.html.twig #}*/
/* */
/* {% extends "OCPlatformBundle::layout.html.twig" %}*/
/* */
/* {% block title %}*/
/*   Accueil - {{ parent() }}*/
/* {% endblock %}*/
/* */
/* {% block ocplatform_body %}*/
/* */
/*   <h2>Liste des annonces</h2>*/
/* */
/*   <ul>*/
/*     {% for advert in listAdverts %}*/
/*       <li>*/
/*         <a href="{{ path('oc_platform_view', {'id': advert.id}) }}">*/
/*           {{ advert.title }}*/
/*         </a>*/
/*         par {{ advert.author }},*/
/*         le {{ advert.date|date('d/m/Y') }}*/
/*       </li>*/
/*     {% else %}*/
/*       <li>Pas (encore !) d'annonces</li>*/
/*     {% endfor %}*/
/*   </ul>*/
/* */
/* {% endblock %}*/
