<?php

/* @WebProfiler/Profiler/toolbar_redirect.html.twig */
class __TwigTemplate_d3baf363beb95523bd85358add559d06f8dab2b3b65a4aa5b41c90a428e2d9cd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "@WebProfiler/Profiler/toolbar_redirect.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_287a236086a74ed3654abcd945ed089274ec423f6e6b0f36e8ba1e1d44a3831b = $this->env->getExtension("native_profiler");
        $__internal_287a236086a74ed3654abcd945ed089274ec423f6e6b0f36e8ba1e1d44a3831b->enter($__internal_287a236086a74ed3654abcd945ed089274ec423f6e6b0f36e8ba1e1d44a3831b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/toolbar_redirect.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_287a236086a74ed3654abcd945ed089274ec423f6e6b0f36e8ba1e1d44a3831b->leave($__internal_287a236086a74ed3654abcd945ed089274ec423f6e6b0f36e8ba1e1d44a3831b_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_144c28c1bca6595d083c5b8e15284704ba7b1a54ab8bc9500f3e0ee8f9ae6b7d = $this->env->getExtension("native_profiler");
        $__internal_144c28c1bca6595d083c5b8e15284704ba7b1a54ab8bc9500f3e0ee8f9ae6b7d->enter($__internal_144c28c1bca6595d083c5b8e15284704ba7b1a54ab8bc9500f3e0ee8f9ae6b7d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Redirection Intercepted";
        
        $__internal_144c28c1bca6595d083c5b8e15284704ba7b1a54ab8bc9500f3e0ee8f9ae6b7d->leave($__internal_144c28c1bca6595d083c5b8e15284704ba7b1a54ab8bc9500f3e0ee8f9ae6b7d_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_4b016cc049fb8a0d95eba54244f55843669d1e0f2912441d26a9bbb97914d2a7 = $this->env->getExtension("native_profiler");
        $__internal_4b016cc049fb8a0d95eba54244f55843669d1e0f2912441d26a9bbb97914d2a7->enter($__internal_4b016cc049fb8a0d95eba54244f55843669d1e0f2912441d26a9bbb97914d2a7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"";
        // line 8
        echo twig_escape_filter($this->env, (isset($context["location"]) ? $context["location"] : $this->getContext($context, "location")), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, (isset($context["location"]) ? $context["location"] : $this->getContext($context, "location")), "html", null, true);
        echo "</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
";
        
        $__internal_4b016cc049fb8a0d95eba54244f55843669d1e0f2912441d26a9bbb97914d2a7->leave($__internal_4b016cc049fb8a0d95eba54244f55843669d1e0f2912441d26a9bbb97914d2a7_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/toolbar_redirect.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  57 => 8,  53 => 6,  47 => 5,  35 => 3,  11 => 1,);
    }
}
/* {% extends '@Twig/layout.html.twig' %}*/
/* */
/* {% block title 'Redirection Intercepted' %}*/
/* */
/* {% block body %}*/
/*     <div class="sf-reset">*/
/*         <div class="block-exception">*/
/*             <h1>This request redirects to <a href="{{ location }}">{{ location }}</a>.</h1>*/
/* */
/*             <p>*/
/*                 <small>*/
/*                     The redirect was intercepted by the web debug toolbar to help debugging.*/
/*                     For more information, see the "intercept-redirects" option of the Profiler.*/
/*                 </small>*/
/*             </p>*/
/*         </div>*/
/*     </div>*/
/* {% endblock %}*/
/* */
