<?php

/* @Framework/Form/hidden_row.html.php */
class __TwigTemplate_3999fa260011ebc67c403d66511a5a914bfbc5c8394169eff49ef91a613efa97 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_880cc049e95013fccafa365762fcd1f31d5b47c674f9c37d8fe544c71af5d965 = $this->env->getExtension("native_profiler");
        $__internal_880cc049e95013fccafa365762fcd1f31d5b47c674f9c37d8fe544c71af5d965->enter($__internal_880cc049e95013fccafa365762fcd1f31d5b47c674f9c37d8fe544c71af5d965_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->widget(\$form) ?>
";
        
        $__internal_880cc049e95013fccafa365762fcd1f31d5b47c674f9c37d8fe544c71af5d965->leave($__internal_880cc049e95013fccafa365762fcd1f31d5b47c674f9c37d8fe544c71af5d965_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->widget($form) ?>*/
/* */
