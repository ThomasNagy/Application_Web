<?php

/* TwigBundle:Exception:exception.rdf.twig */
class __TwigTemplate_4aae93cc5e1a4cfc2dafe3e731d5dbc8404c187394a338b4b1cb9835503ee33c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_56781e29df0a81ddda1af6e5593e9c602ccf472f0b58de42501a7d026370e9f2 = $this->env->getExtension("native_profiler");
        $__internal_56781e29df0a81ddda1af6e5593e9c602ccf472f0b58de42501a7d026370e9f2->enter($__internal_56781e29df0a81ddda1af6e5593e9c602ccf472f0b58de42501a7d026370e9f2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/exception.xml.twig", "TwigBundle:Exception:exception.rdf.twig", 1)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        
        $__internal_56781e29df0a81ddda1af6e5593e9c602ccf472f0b58de42501a7d026370e9f2->leave($__internal_56781e29df0a81ddda1af6e5593e9c602ccf472f0b58de42501a7d026370e9f2_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/exception.xml.twig' with { 'exception': exception } %}*/
/* */
