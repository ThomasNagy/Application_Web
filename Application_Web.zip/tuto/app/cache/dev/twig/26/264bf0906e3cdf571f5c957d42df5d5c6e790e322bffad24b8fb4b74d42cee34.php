<?php

/* @Framework/Form/choice_options.html.php */
class __TwigTemplate_2e704286945c03775f59135f78b557522e503213b9e95fa50e29de8a98d78116 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4836df880120ca9fe1c23e75876d81d830f414ceaea6b4cc52eb67fa21cae273 = $this->env->getExtension("native_profiler");
        $__internal_4836df880120ca9fe1c23e75876d81d830f414ceaea6b4cc52eb67fa21cae273->enter($__internal_4836df880120ca9fe1c23e75876d81d830f414ceaea6b4cc52eb67fa21cae273_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
";
        
        $__internal_4836df880120ca9fe1c23e75876d81d830f414ceaea6b4cc52eb67fa21cae273->leave($__internal_4836df880120ca9fe1c23e75876d81d830f414ceaea6b4cc52eb67fa21cae273_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_options.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'choice_widget_options') ?>*/
/* */
