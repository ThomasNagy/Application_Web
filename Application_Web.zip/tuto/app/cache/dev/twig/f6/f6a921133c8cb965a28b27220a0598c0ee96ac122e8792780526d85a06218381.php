<?php

/* TwigBundle:Exception:error.xml.twig */
class __TwigTemplate_19cb73b02f5586bc419cedac4c9b638cac89bcb6e0ee6e40ea94c3c3d971bcb5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8f5da8546079d1dd235c2b8eda3f293f92be2e92ca1f44f61cbf2846aad9cb97 = $this->env->getExtension("native_profiler");
        $__internal_8f5da8546079d1dd235c2b8eda3f293f92be2e92ca1f44f61cbf2846aad9cb97->enter($__internal_8f5da8546079d1dd235c2b8eda3f293f92be2e92ca1f44f61cbf2846aad9cb97_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.xml.twig"));

        // line 1
        echo "<?xml version=\"1.0\" encoding=\"";
        echo twig_escape_filter($this->env, $this->env->getCharset(), "html", null, true);
        echo "\" ?>

<error code=\"";
        // line 3
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "html", null, true);
        echo "\" message=\"";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "html", null, true);
        echo "\" />
";
        
        $__internal_8f5da8546079d1dd235c2b8eda3f293f92be2e92ca1f44f61cbf2846aad9cb97->leave($__internal_8f5da8546079d1dd235c2b8eda3f293f92be2e92ca1f44f61cbf2846aad9cb97_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.xml.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 3,  22 => 1,);
    }
}
/* <?xml version="1.0" encoding="{{ _charset }}" ?>*/
/* */
/* <error code="{{ status_code }}" message="{{ status_text }}" />*/
/* */
