<?php

/* @Twig/Exception/error.rdf.twig */
class __TwigTemplate_d3b809de8b2469b7ec55c99ac9fee2171744b5fb4761273c801faa0f5536beaa extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_125decc9aaf366d45d3f862eb3608b6e8cbd557d3c936b1e4781792beff63797 = $this->env->getExtension("native_profiler");
        $__internal_125decc9aaf366d45d3f862eb3608b6e8cbd557d3c936b1e4781792beff63797->enter($__internal_125decc9aaf366d45d3f862eb3608b6e8cbd557d3c936b1e4781792beff63797_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "@Twig/Exception/error.rdf.twig", 1)->display($context);
        
        $__internal_125decc9aaf366d45d3f862eb3608b6e8cbd557d3c936b1e4781792beff63797->leave($__internal_125decc9aaf366d45d3f862eb3608b6e8cbd557d3c936b1e4781792beff63797_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.rdf.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/error.xml.twig' %}*/
/* */
