<?php

/* @Framework/Form/percent_widget.html.php */
class __TwigTemplate_f0aeb2928e9258a0a8df94c84a8c45ca58b76f2d801f81524d8b7f712f118714 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c84f05e64c98cbcb653f59719b70b5e46020e38f2d6a47ecbcac06852c424013 = $this->env->getExtension("native_profiler");
        $__internal_c84f05e64c98cbcb653f59719b70b5e46020e38f2d6a47ecbcac06852c424013->enter($__internal_c84f05e64c98cbcb653f59719b70b5e46020e38f2d6a47ecbcac06852c424013_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/percent_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'text')) ?> %
";
        
        $__internal_c84f05e64c98cbcb653f59719b70b5e46020e38f2d6a47ecbcac06852c424013->leave($__internal_c84f05e64c98cbcb653f59719b70b5e46020e38f2d6a47ecbcac06852c424013_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/percent_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'text')) ?> %*/
/* */
