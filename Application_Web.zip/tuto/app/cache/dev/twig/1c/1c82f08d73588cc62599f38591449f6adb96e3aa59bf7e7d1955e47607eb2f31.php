<?php

/* @OCPlatform/Default/form.html.twig */
class __TwigTemplate_ade712f7f7d72e8917072b1ca65fdaf8e4ecd0a4e1030b2d66afae75410f3041 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f9b7ff89f7ca1c0d7b43075c7984ff153964ef70dd61aa14b9e2a86c4392b071 = $this->env->getExtension("native_profiler");
        $__internal_f9b7ff89f7ca1c0d7b43075c7984ff153964ef70dd61aa14b9e2a86c4392b071->enter($__internal_f9b7ff89f7ca1c0d7b43075c7984ff153964ef70dd61aa14b9e2a86c4392b071_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@OCPlatform/Default/form.html.twig"));

        // line 2
        echo "
<h3>Formulaire d'annonce</h3>

";
        // line 7
        echo "<div class=\"well\">
  Ici se trouvera le formulaire.
</div>";
        
        $__internal_f9b7ff89f7ca1c0d7b43075c7984ff153964ef70dd61aa14b9e2a86c4392b071->leave($__internal_f9b7ff89f7ca1c0d7b43075c7984ff153964ef70dd61aa14b9e2a86c4392b071_prof);

    }

    public function getTemplateName()
    {
        return "@OCPlatform/Default/form.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  27 => 7,  22 => 2,);
    }
}
/* {# src/OC/PlatformBundle/Resources/views/Advert/form.html.twig #}*/
/* */
/* <h3>Formulaire d'annonce</h3>*/
/* */
/* {# On laisse vide la vue pour l'instant, on la comblera plus tard*/
/*    lorsqu'on saura afficher un formulaire. #}*/
/* <div class="well">*/
/*   Ici se trouvera le formulaire.*/
/* </div>*/
