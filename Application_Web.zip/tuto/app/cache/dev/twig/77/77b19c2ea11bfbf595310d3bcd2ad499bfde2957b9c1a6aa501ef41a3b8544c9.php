<?php

/* OCPlatformBundle:Blog:translation.html.twig */
class __TwigTemplate_309791e4af07af1ebc0e7cd51a11f4dc5f1bff195e703b6566c432342c2a043c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9d227192866a4351cfdc390561773dac14a1b69c489fd4b682d8488774a03ae5 = $this->env->getExtension("native_profiler");
        $__internal_9d227192866a4351cfdc390561773dac14a1b69c489fd4b682d8488774a03ae5->enter($__internal_9d227192866a4351cfdc390561773dac14a1b69c489fd4b682d8488774a03ae5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle:Blog:translation.html.twig"));

        // line 1
        echo "<html>
  <body>
    Hello ";
        // line 3
        echo twig_escape_filter($this->env, (isset($context["name"]) ? $context["name"] : $this->getContext($context, "name")), "html", null, true);
        echo "!
  </body>
</html>
";
        
        $__internal_9d227192866a4351cfdc390561773dac14a1b69c489fd4b682d8488774a03ae5->leave($__internal_9d227192866a4351cfdc390561773dac14a1b69c489fd4b682d8488774a03ae5_prof);

    }

    public function getTemplateName()
    {
        return "OCPlatformBundle:Blog:translation.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  26 => 3,  22 => 1,);
    }
}
/* <html>*/
/*   <body>*/
/*     Hello {{ name }}!*/
/*   </body>*/
/* </html>*/
/* */
