<?php

/* @Twig/Exception/exception.css.twig */
class __TwigTemplate_a9657b308338266fc3e8da21671a0761cde583482d9e339fd75f6c8e46cc9e0d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bdc3363fc2e9fcf7ba133a8177b79db8639173052ffa6af473a0a887aeb8005d = $this->env->getExtension("native_profiler");
        $__internal_bdc3363fc2e9fcf7ba133a8177b79db8639173052ffa6af473a0a887aeb8005d->enter($__internal_bdc3363fc2e9fcf7ba133a8177b79db8639173052ffa6af473a0a887aeb8005d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        $this->loadTemplate("@Twig/Exception/exception.txt.twig", "@Twig/Exception/exception.css.twig", 2)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        // line 3
        echo "*/
";
        
        $__internal_bdc3363fc2e9fcf7ba133a8177b79db8639173052ffa6af473a0a887aeb8005d->leave($__internal_bdc3363fc2e9fcf7ba133a8177b79db8639173052ffa6af473a0a887aeb8005d_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  27 => 3,  25 => 2,  22 => 1,);
    }
}
/* /**/
/* {% include '@Twig/Exception/exception.txt.twig' with { 'exception': exception } %}*/
/* *//* */
/* */
