<?php

/* @Framework/Form/url_widget.html.php */
class __TwigTemplate_41f60dd50519896c7a6c109cbcf56a55dab20a120905a7e44dabeb7ab455abb2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_652f07c851e18956ea5ee54e3eabd4c5b73a26bc78139b3a28187918d58a1aa3 = $this->env->getExtension("native_profiler");
        $__internal_652f07c851e18956ea5ee54e3eabd4c5b73a26bc78139b3a28187918d58a1aa3->enter($__internal_652f07c851e18956ea5ee54e3eabd4c5b73a26bc78139b3a28187918d58a1aa3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/url_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'url')) ?>
";
        
        $__internal_652f07c851e18956ea5ee54e3eabd4c5b73a26bc78139b3a28187918d58a1aa3->leave($__internal_652f07c851e18956ea5ee54e3eabd4c5b73a26bc78139b3a28187918d58a1aa3_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/url_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'url')) ?>*/
/* */
