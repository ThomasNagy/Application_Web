<?php

/* @Framework/FormTable/form_widget_compound.html.php */
class __TwigTemplate_4c81ba649cb07e703f1a6f863eeb48f03a231606f9b116b38ee27992437a1fab extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_01a829ff41175dfa2822c0110cd1ec69c72fc3d607799b75234e2016109a153f = $this->env->getExtension("native_profiler");
        $__internal_01a829ff41175dfa2822c0110cd1ec69c72fc3d607799b75234e2016109a153f->enter($__internal_01a829ff41175dfa2822c0110cd1ec69c72fc3d607799b75234e2016109a153f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_widget_compound.html.php"));

        // line 1
        echo "<table <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <tr>
        <td colspan=\"2\">
            <?php echo \$view['form']->errors(\$form) ?>
        </td>
    </tr>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</table>
";
        
        $__internal_01a829ff41175dfa2822c0110cd1ec69c72fc3d607799b75234e2016109a153f->leave($__internal_01a829ff41175dfa2822c0110cd1ec69c72fc3d607799b75234e2016109a153f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_widget_compound.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <table <?php echo $view['form']->block($form, 'widget_container_attributes') ?>>*/
/*     <?php if (!$form->parent && $errors): ?>*/
/*     <tr>*/
/*         <td colspan="2">*/
/*             <?php echo $view['form']->errors($form) ?>*/
/*         </td>*/
/*     </tr>*/
/*     <?php endif ?>*/
/*     <?php echo $view['form']->block($form, 'form_rows') ?>*/
/*     <?php echo $view['form']->rest($form) ?>*/
/* </table>*/
/* */
