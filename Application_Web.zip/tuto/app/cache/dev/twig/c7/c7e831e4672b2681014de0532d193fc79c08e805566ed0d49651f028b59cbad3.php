<?php

/* @Framework/FormTable/button_row.html.php */
class __TwigTemplate_ac436b8d438515519188565b9e4b1b1ddca575ccd257bcd45be83e1ec9c6507a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c94a3f097c83975ee606f13fb2d53729e2b6983a24085948bfca74c0f94fbcde = $this->env->getExtension("native_profiler");
        $__internal_c94a3f097c83975ee606f13fb2d53729e2b6983a24085948bfca74c0f94fbcde->enter($__internal_c94a3f097c83975ee606f13fb2d53729e2b6983a24085948bfca74c0f94fbcde_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        // line 1
        echo "<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_c94a3f097c83975ee606f13fb2d53729e2b6983a24085948bfca74c0f94fbcde->leave($__internal_c94a3f097c83975ee606f13fb2d53729e2b6983a24085948bfca74c0f94fbcde_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <tr>*/
/*     <td></td>*/
/*     <td>*/
/*         <?php echo $view['form']->widget($form) ?>*/
/*     </td>*/
/* </tr>*/
/* */
