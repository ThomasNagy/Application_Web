<?php

/* @WebProfiler/Icon/yes.svg */
class __TwigTemplate_9092d6bc6d35ebb83ee4ec11f51bddf7b297b3e1f721cee1f45ff8200c67c9d2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ca0cf0255a59a78ed79755331d6b52f4f7f10279884592921a3a12f17b5c9e13 = $this->env->getExtension("native_profiler");
        $__internal_ca0cf0255a59a78ed79755331d6b52f4f7f10279884592921a3a12f17b5c9e13->enter($__internal_ca0cf0255a59a78ed79755331d6b52f4f7f10279884592921a3a12f17b5c9e13_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Icon/yes.svg"));

        // line 1
        echo "<svg version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" x=\"0px\" y=\"0px\" height=\"28\" viewBox=\"0 0 12 12\" enable-background=\"new 0 0 12 12\" xml:space=\"preserve\">
    <path fill=\"#5E976E\" d=\"M12,3.1c0,0.4-0.1,0.8-0.4,1.1L5.9,9.8c-0.3,0.3-0.6,0.4-1,0.4c-0.4,0-0.7-0.1-1-0.4L0.4,6.3
    C0.1,6,0,5.6,0,5.2c0-0.4,0.2-0.7,0.4-0.9C0.6,4,1,3.9,1.3,3.9c0.4,0,0.8,0.1,1.1,0.4l2.5,2.5l4.7-4.7c0.3-0.3,0.7-0.4,1-0.4
    c0.4,0,0.7,0.2,0.9,0.4C11.8,2.4,12,2.7,12,3.1z\"/>
</svg>
";
        
        $__internal_ca0cf0255a59a78ed79755331d6b52f4f7f10279884592921a3a12f17b5c9e13->leave($__internal_ca0cf0255a59a78ed79755331d6b52f4f7f10279884592921a3a12f17b5c9e13_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Icon/yes.svg";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <svg version="1.1" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" height="28" viewBox="0 0 12 12" enable-background="new 0 0 12 12" xml:space="preserve">*/
/*     <path fill="#5E976E" d="M12,3.1c0,0.4-0.1,0.8-0.4,1.1L5.9,9.8c-0.3,0.3-0.6,0.4-1,0.4c-0.4,0-0.7-0.1-1-0.4L0.4,6.3*/
/*     C0.1,6,0,5.6,0,5.2c0-0.4,0.2-0.7,0.4-0.9C0.6,4,1,3.9,1.3,3.9c0.4,0,0.8,0.1,1.1,0.4l2.5,2.5l4.7-4.7c0.3-0.3,0.7-0.4,1-0.4*/
/*     c0.4,0,0.7,0.2,0.9,0.4C11.8,2.4,12,2.7,12,3.1z"/>*/
/* </svg>*/
/* */
