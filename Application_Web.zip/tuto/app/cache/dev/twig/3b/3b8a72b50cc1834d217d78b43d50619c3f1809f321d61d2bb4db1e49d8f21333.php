<?php

/* @Framework/Form/hidden_widget.html.php */
class __TwigTemplate_4c7e964ca582effae4aff78bbf9436537ca7a1baed268ad5f49cd5bfccf3b4ab extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5bf1a57ce67a8d4918b05b0b20822a3049f4af842b5cf4967e9d037ecec73792 = $this->env->getExtension("native_profiler");
        $__internal_5bf1a57ce67a8d4918b05b0b20822a3049f4af842b5cf4967e9d037ecec73792->enter($__internal_5bf1a57ce67a8d4918b05b0b20822a3049f4af842b5cf4967e9d037ecec73792_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'hidden')) ?>
";
        
        $__internal_5bf1a57ce67a8d4918b05b0b20822a3049f4af842b5cf4967e9d037ecec73792->leave($__internal_5bf1a57ce67a8d4918b05b0b20822a3049f4af842b5cf4967e9d037ecec73792_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'hidden')) ?>*/
/* */
