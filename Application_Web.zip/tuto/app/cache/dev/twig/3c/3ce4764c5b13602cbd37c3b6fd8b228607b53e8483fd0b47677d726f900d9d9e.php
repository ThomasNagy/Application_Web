<?php

/* TwigBundle:Exception:error.atom.twig */
class __TwigTemplate_c0f9b58bb462586a3720919c191a6f0a9c3c3784b1b5690e5d5e7cb84bfeda2f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_89e8d2fbc4c01ed8022a141592cdcee45a4827ba91451b47f9a7ea1e15c506c6 = $this->env->getExtension("native_profiler");
        $__internal_89e8d2fbc4c01ed8022a141592cdcee45a4827ba91451b47f9a7ea1e15c506c6->enter($__internal_89e8d2fbc4c01ed8022a141592cdcee45a4827ba91451b47f9a7ea1e15c506c6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "TwigBundle:Exception:error.atom.twig", 1)->display($context);
        
        $__internal_89e8d2fbc4c01ed8022a141592cdcee45a4827ba91451b47f9a7ea1e15c506c6->leave($__internal_89e8d2fbc4c01ed8022a141592cdcee45a4827ba91451b47f9a7ea1e15c506c6_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.atom.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/error.xml.twig' %}*/
/* */
