<?php

/* @Framework/Form/choice_widget_expanded.html.php */
class __TwigTemplate_ddb5b95a4d7b8f4fba2ebbdd1165b094d0d348b7e060c7eafa8864e121c0adf0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_67b251a0c37dce713083f6d68d3f246c1e2c19f073a8fc00175a5b364e4fc3ac = $this->env->getExtension("native_profiler");
        $__internal_67b251a0c37dce713083f6d68d3f246c1e2c19f073a8fc00175a5b364e4fc3ac->enter($__internal_67b251a0c37dce713083f6d68d3f246c1e2c19f073a8fc00175a5b364e4fc3ac_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget_expanded.html.php"));

        // line 1
        echo "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
<?php foreach (\$form as \$child): ?>
    <?php echo \$view['form']->widget(\$child) ?>
    <?php echo \$view['form']->label(\$child, null, array('translation_domain' => \$choice_translation_domain)) ?>
<?php endforeach ?>
</div>
";
        
        $__internal_67b251a0c37dce713083f6d68d3f246c1e2c19f073a8fc00175a5b364e4fc3ac->leave($__internal_67b251a0c37dce713083f6d68d3f246c1e2c19f073a8fc00175a5b364e4fc3ac_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget_expanded.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div <?php echo $view['form']->block($form, 'widget_container_attributes') ?>>*/
/* <?php foreach ($form as $child): ?>*/
/*     <?php echo $view['form']->widget($child) ?>*/
/*     <?php echo $view['form']->label($child, null, array('translation_domain' => $choice_translation_domain)) ?>*/
/* <?php endforeach ?>*/
/* </div>*/
/* */
