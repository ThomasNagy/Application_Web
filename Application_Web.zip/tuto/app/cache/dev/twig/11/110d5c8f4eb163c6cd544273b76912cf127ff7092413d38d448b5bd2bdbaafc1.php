<?php

/* OCPlatformBundle:Advert:index.html.twig */
class __TwigTemplate_273e8c51e6992bfdd4427b3b1b4ba909b317167852466fdc9d1f3e01d511a0c5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e450e0cca1505a3759f874b5656f55693745c489923c861b2ac149646c55d546 = $this->env->getExtension("native_profiler");
        $__internal_e450e0cca1505a3759f874b5656f55693745c489923c861b2ac149646c55d546->enter($__internal_e450e0cca1505a3759f874b5656f55693745c489923c861b2ac149646c55d546_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "OCPlatformBundle:Advert:index.html.twig"));

        // line 2
        echo "
<!DOCTYPE html>
<html>
    <head>
        <title>Bienvenue sur ma première page avec OpenClassrooms !</title>
    </head>
    <body>
        <h1>Hello World !</h1>
        
        <p>
            Le Hello World est un grand classique en programmation.
            Il signifie énormément, car cela veut dire que vous avez
            réussi à exécuter le programme pour accomplir une tâche simple :
            afficher ce hello world !
        </p>
    </body>
</html>";
        
        $__internal_e450e0cca1505a3759f874b5656f55693745c489923c861b2ac149646c55d546->leave($__internal_e450e0cca1505a3759f874b5656f55693745c489923c861b2ac149646c55d546_prof);

    }

    public function getTemplateName()
    {
        return "OCPlatformBundle:Advert:index.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 2,);
    }
}
/* {# src/OC/PlatformBundle/Resources/views/Advert/index.html.twig #}*/
/* */
/* <!DOCTYPE html>*/
/* <html>*/
/*     <head>*/
/*         <title>Bienvenue sur ma première page avec OpenClassrooms !</title>*/
/*     </head>*/
/*     <body>*/
/*         <h1>Hello World !</h1>*/
/*         */
/*         <p>*/
/*             Le Hello World est un grand classique en programmation.*/
/*             Il signifie énormément, car cela veut dire que vous avez*/
/*             réussi à exécuter le programme pour accomplir une tâche simple :*/
/*             afficher ce hello world !*/
/*         </p>*/
/*     </body>*/
/* </html>*/
