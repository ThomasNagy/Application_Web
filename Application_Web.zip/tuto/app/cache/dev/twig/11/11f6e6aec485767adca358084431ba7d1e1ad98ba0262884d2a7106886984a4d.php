<?php

/* @Framework/Form/textarea_widget.html.php */
class __TwigTemplate_92ed3bb83bccd9c098a16b1e64045cd6eb4a283956f3a0c863bb9105e3f9181f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_197c1d46866ddee71772ceaeeb5b9852626f5591c083fee705766df39d020e22 = $this->env->getExtension("native_profiler");
        $__internal_197c1d46866ddee71772ceaeeb5b9852626f5591c083fee705766df39d020e22->enter($__internal_197c1d46866ddee71772ceaeeb5b9852626f5591c083fee705766df39d020e22_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        // line 1
        echo "<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
";
        
        $__internal_197c1d46866ddee71772ceaeeb5b9852626f5591c083fee705766df39d020e22->leave($__internal_197c1d46866ddee71772ceaeeb5b9852626f5591c083fee705766df39d020e22_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/textarea_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <textarea <?php echo $view['form']->block($form, 'widget_attributes') ?>><?php echo $view->escape($value) ?></textarea>*/
/* */
