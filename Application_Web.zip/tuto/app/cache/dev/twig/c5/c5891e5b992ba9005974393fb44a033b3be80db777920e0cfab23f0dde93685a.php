<?php

/* @Framework/Form/form_widget_compound.html.php */
class __TwigTemplate_349ccd46e80d94d3e0f3a7325ed7d8bd154ec915d160f5395ec5f84c08dd22f4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_00980c800977ca432d9e03b16a7c86a38553dd46c3786288b37efd1b149422d8 = $this->env->getExtension("native_profiler");
        $__internal_00980c800977ca432d9e03b16a7c86a38553dd46c3786288b37efd1b149422d8->enter($__internal_00980c800977ca432d9e03b16a7c86a38553dd46c3786288b37efd1b149422d8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_compound.html.php"));

        // line 1
        echo "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</div>
";
        
        $__internal_00980c800977ca432d9e03b16a7c86a38553dd46c3786288b37efd1b149422d8->leave($__internal_00980c800977ca432d9e03b16a7c86a38553dd46c3786288b37efd1b149422d8_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget_compound.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div <?php echo $view['form']->block($form, 'widget_container_attributes') ?>>*/
/*     <?php if (!$form->parent && $errors): ?>*/
/*     <?php echo $view['form']->errors($form) ?>*/
/*     <?php endif ?>*/
/*     <?php echo $view['form']->block($form, 'form_rows') ?>*/
/*     <?php echo $view['form']->rest($form) ?>*/
/* </div>*/
/* */
