<?php

/* @Twig/Exception/error.atom.twig */
class __TwigTemplate_4c42e5556a8c185eba78f5836dc62bd92271bdf674da2c4c40d6df065fda0fe6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9be4098c856c5ac4c7723d020ca9e875607f60d6d47f8a6333a3b0218d44bf56 = $this->env->getExtension("native_profiler");
        $__internal_9be4098c856c5ac4c7723d020ca9e875607f60d6d47f8a6333a3b0218d44bf56->enter($__internal_9be4098c856c5ac4c7723d020ca9e875607f60d6d47f8a6333a3b0218d44bf56_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "@Twig/Exception/error.atom.twig", 1)->display($context);
        
        $__internal_9be4098c856c5ac4c7723d020ca9e875607f60d6d47f8a6333a3b0218d44bf56->leave($__internal_9be4098c856c5ac4c7723d020ca9e875607f60d6d47f8a6333a3b0218d44bf56_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.atom.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/error.xml.twig' %}*/
/* */
