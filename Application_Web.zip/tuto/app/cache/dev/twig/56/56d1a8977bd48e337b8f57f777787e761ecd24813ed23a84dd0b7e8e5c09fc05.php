<?php

/* @Framework/Form/submit_widget.html.php */
class __TwigTemplate_f87371dc3db4ed29effbe06f2b437b4d4dd7963e7dc2971beb7f6134f67802c1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_87fbbfbe8cac904c616cebbccd09cbb2716b9afd40b33da5cefec4f566dca185 = $this->env->getExtension("native_profiler");
        $__internal_87fbbfbe8cac904c616cebbccd09cbb2716b9afd40b33da5cefec4f566dca185->enter($__internal_87fbbfbe8cac904c616cebbccd09cbb2716b9afd40b33da5cefec4f566dca185_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/submit_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget',  array('type' => isset(\$type) ? \$type : 'submit')) ?>
";
        
        $__internal_87fbbfbe8cac904c616cebbccd09cbb2716b9afd40b33da5cefec4f566dca185->leave($__internal_87fbbfbe8cac904c616cebbccd09cbb2716b9afd40b33da5cefec4f566dca185_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/submit_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'button_widget',  array('type' => isset($type) ? $type : 'submit')) ?>*/
/* */
