<?php

/* @Framework/Form/password_widget.html.php */
class __TwigTemplate_b25df1fbbdde4fa1884b7469746050365053706c3420ca753fa30797e0c46da9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fbaa230ed586e8652c244490f49818ea1a9d7288bb65490e57765ad49319bb1b = $this->env->getExtension("native_profiler");
        $__internal_fbaa230ed586e8652c244490f49818ea1a9d7288bb65490e57765ad49319bb1b->enter($__internal_fbaa230ed586e8652c244490f49818ea1a9d7288bb65490e57765ad49319bb1b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'password')) ?>
";
        
        $__internal_fbaa230ed586e8652c244490f49818ea1a9d7288bb65490e57765ad49319bb1b->leave($__internal_fbaa230ed586e8652c244490f49818ea1a9d7288bb65490e57765ad49319bb1b_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/password_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'password')) ?>*/
/* */
