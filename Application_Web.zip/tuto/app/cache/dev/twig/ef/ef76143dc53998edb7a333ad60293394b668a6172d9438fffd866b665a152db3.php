<?php

/* @Framework/Form/form_widget.html.php */
class __TwigTemplate_fdb03d2bc3e69744276773c5fd4afe002138046050f991d94c00bf617b12cad7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_38bf6477e6848e3d05d25cedbde481575f6b7bc2185319f34dcfee50e3f055b5 = $this->env->getExtension("native_profiler");
        $__internal_38bf6477e6848e3d05d25cedbde481575f6b7bc2185319f34dcfee50e3f055b5->enter($__internal_38bf6477e6848e3d05d25cedbde481575f6b7bc2185319f34dcfee50e3f055b5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget.html.php"));

        // line 1
        echo "<?php if (\$compound): ?>
<?php echo \$view['form']->block(\$form, 'form_widget_compound')?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'form_widget_simple')?>
<?php endif ?>
";
        
        $__internal_38bf6477e6848e3d05d25cedbde481575f6b7bc2185319f34dcfee50e3f055b5->leave($__internal_38bf6477e6848e3d05d25cedbde481575f6b7bc2185319f34dcfee50e3f055b5_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if ($compound): ?>*/
/* <?php echo $view['form']->block($form, 'form_widget_compound')?>*/
/* <?php else: ?>*/
/* <?php echo $view['form']->block($form, 'form_widget_simple')?>*/
/* <?php endif ?>*/
/* */
