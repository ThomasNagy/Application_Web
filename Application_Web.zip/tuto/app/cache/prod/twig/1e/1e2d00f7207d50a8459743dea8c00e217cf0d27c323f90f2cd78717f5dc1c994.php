<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_a290374183e9b73315d19a18ecbaefae847b22fc5e085b2a345f83c2ec1ff882 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }
}
