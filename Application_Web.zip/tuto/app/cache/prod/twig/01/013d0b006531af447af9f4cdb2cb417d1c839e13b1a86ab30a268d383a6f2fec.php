<?php

/* @OCPlatform/Blog/translation.html.twig */
class __TwigTemplate_296a51678a2287cd7cc952eff52dcf69b1eeb08b1a5a7201abfa3c1b1fa4134b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<html>
  <body>
    Hello ";
        // line 3
        echo twig_escape_filter($this->env, (isset($context["name"]) ? $context["name"] : null), "html", null, true);
        echo "!
  </body>
</html>
";
    }

    public function getTemplateName()
    {
        return "@OCPlatform/Blog/translation.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  23 => 3,  19 => 1,);
    }
}
/* <html>*/
/*   <body>*/
/*     Hello {{ name }}!*/
/*   </body>*/
/* </html>*/
/* */
