<?php

/* OCPlatformBundle:Advert:form.html.twig */
class __TwigTemplate_ef1adaa13ce0c25c477bb56a6ca4ef85fe97a21a8034b93dce4232efbb612198 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 2
        echo "
<h3>Formulaire d'annonce</h3>

";
        // line 7
        echo "<div class=\"well\">
  Ici se trouvera le formulaire.
</div>";
    }

    public function getTemplateName()
    {
        return "OCPlatformBundle:Advert:form.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  24 => 7,  19 => 2,);
    }
}
/* {# src/OC/PlatformBundle/Resources/views/Default/form.html.twig #}*/
/* */
/* <h3>Formulaire d'annonce</h3>*/
/* */
/* {# On laisse vide la vue pour l'instant, on la comblera plus tard*/
/*    lorsqu'on saura afficher un formulaire. #}*/
/* <div class="well">*/
/*   Ici se trouvera le formulaire.*/
/* </div>*/
