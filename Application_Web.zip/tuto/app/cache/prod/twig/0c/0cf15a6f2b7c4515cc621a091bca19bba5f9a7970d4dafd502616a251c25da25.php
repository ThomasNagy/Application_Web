<?php

/* @OCPlatform/Advert/form.html.twig */
class __TwigTemplate_4360d1d310706feda7685e47d5e530c5ecd5e9cecf57cd7d676667ff8cff771c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 2
        echo "
<h3>Formulaire d'annonce</h3>

";
        // line 7
        echo "<div class=\"well\">
  Ici se trouvera le formulaire.
</div>";
    }

    public function getTemplateName()
    {
        return "@OCPlatform/Advert/form.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  24 => 7,  19 => 2,);
    }
}
/* {# src/OC/PlatformBundle/Resources/views/Default/form.html.twig #}*/
/* */
/* <h3>Formulaire d'annonce</h3>*/
/* */
/* {# On laisse vide la vue pour l'instant, on la comblera plus tard*/
/*    lorsqu'on saura afficher un formulaire. #}*/
/* <div class="well">*/
/*   Ici se trouvera le formulaire.*/
/* </div>*/
