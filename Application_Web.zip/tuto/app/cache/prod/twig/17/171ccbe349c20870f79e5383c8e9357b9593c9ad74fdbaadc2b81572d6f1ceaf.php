<?php

/* OCPlatformBundle:Blog:translation.html.twig */
class __TwigTemplate_86e3a101616ffcec4666d3e0d8392f6ca242a1422fa42611fc25193c3aa8943e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<html>
  <body>
    Hello ";
        // line 3
        echo twig_escape_filter($this->env, (isset($context["name"]) ? $context["name"] : null), "html", null, true);
        echo "!
  </body>
</html>
";
    }

    public function getTemplateName()
    {
        return "OCPlatformBundle:Blog:translation.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  23 => 3,  19 => 1,);
    }
}
/* <html>*/
/*   <body>*/
/*     Hello {{ name }}!*/
/*   </body>*/
/* </html>*/
/* */
